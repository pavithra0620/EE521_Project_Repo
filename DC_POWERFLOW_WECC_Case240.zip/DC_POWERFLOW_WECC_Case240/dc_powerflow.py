"""
DC Power Flow Analysis for Case240
Simplified linear power flow based on DC approximations
"""

import json
import numpy as np
import pandas as pd

print("="*70)
print("DC POWER FLOW ANALYSIS - Case 240")
print("="*70)

# Load case
with open('case240.json', 'r') as f:
    case_data = json.load(f)

baseMVA = case_data['baseMVA']
buses = case_data['buses']
branches = case_data['branches']
generators = case_data['generators']

print(f"\nSystem: {len(buses)} buses, {len(branches)} branches, {len(generators)} generators")

# Build B matrix (susceptance matrix) for DC power flow
print("\nBuilding B-matrix (DC approximation)...")
n_buses = len(buses)
bus_ids = [bus['bus_i'] for bus in buses]
bus_idx_map = {bus_id: idx for idx, bus_id in enumerate(bus_ids)}

B = np.zeros((n_buses, n_buses))

# DC Power Flow Assumptions:
# 1. Voltage magnitudes = 1.0 pu
# 2. Small angle differences: sin(θ) ≈ θ, cos(θ) ≈ 1
# 3. Series resistance negligible: R << X
# 4. Reactive power and losses neglected

for branch in branches:
    if branch['status'] == 0:
        continue
    
    i = bus_idx_map[branch['fbus']]
    j = bus_idx_map[branch['tbus']]
    
    x = branch['x']
    
    if abs(x) > 1e-10:
        b = 1.0 / x  # Susceptance
    else:
        continue  # Skip if reactance is zero
    
    # Build B matrix
    B[i, i] += b
    B[j, j] += b
    B[i, j] -= b
    B[j, i] -= b

print("B-matrix built successfully")

# Calculate total load
total_load = sum([bus['Pd'] for bus in buses])
print(f"Total load: {total_load:,.2f} MW")

# Scale generation to match load (no losses in DC power flow)
total_gen_capacity = sum([gen['Pg'] for gen in generators if gen['status'] == 1])
scale = total_load / total_gen_capacity if total_gen_capacity > 0 else 1.0

print(f"Scaling generation by {scale:.4f} to match load")

# Setup power injections
gen_map = {}
for gen in generators:
    if gen['status'] == 1:
        idx = bus_idx_map[gen['bus']]
        if idx not in gen_map:
            gen_map[idx] = 0.0
        gen_map[idx] += gen['Pg'] * scale

P_inj = np.zeros(n_buses)
for idx, bus in enumerate(buses):
    Pg = gen_map.get(idx, 0.0) / baseMVA
    Pd = bus['Pd'] / baseMVA
    P_inj[idx] = Pg - Pd

# Identify slack bus
slack_idx = None
for idx, bus in enumerate(buses):
    if bus['type'] == 3:
        slack_idx = idx
        break

if slack_idx is None:
    # Use first generator bus as slack
    for idx, bus in enumerate(buses):
        if bus['type'] == 2:
            slack_idx = idx
            break

print(f"\nSlack bus: {bus_ids[slack_idx]}")

# Remove slack bus row and column from B matrix
# Slack bus angle is reference (0 degrees)
B_reduced = np.delete(np.delete(B, slack_idx, axis=0), slack_idx, axis=1)
P_reduced = np.delete(P_inj, slack_idx)

# Solve: B * θ = P
# θ = B^(-1) * P
print("\nSolving DC power flow: B·θ = P")

try:
    theta_reduced = np.linalg.solve(B_reduced, P_reduced)
    
    # Insert slack bus angle (0.0) back
    theta = np.insert(theta_reduced, slack_idx, 0.0)
    theta_deg = np.rad2deg(theta)
    
    print(f"✓ Solution obtained")
    print(f"  Angle range: {theta_deg.min():.2f}° to {theta_deg.max():.2f}°")
    
    # Calculate branch flows
    print("\nCalculating branch power flows...")
    branch_results = []
    
    for branch in branches:
        if branch['status'] == 0:
            continue
        
        i = bus_idx_map[branch['fbus']]
        j = bus_idx_map[branch['tbus']]
        
        x = branch['x']
        
        if abs(x) > 1e-10:
            b = 1.0 / x
        else:
            continue
        
        # DC power flow: P_ij = b * (θ_i - θ_j)
        P_ij = b * (theta[i] - theta[j]) * baseMVA
        P_ji = -P_ij  # Power flow in reverse direction
        
        branch_results.append({
            'From_Bus': branch['fbus'],
            'To_Bus': branch['tbus'],
            'P_from_MW': P_ij,
            'P_to_MW': P_ji,
            'Angle_from_deg': theta_deg[i],
            'Angle_to_deg': theta_deg[j],
            'Angle_diff_deg': theta_deg[i] - theta_deg[j]
        })
    
    # Bus results
    bus_results = []
    for idx, bus in enumerate(buses):
        Pg = gen_map.get(idx, 0.0)
        P_inj_MW = P_inj[idx] * baseMVA
        
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'Angle_deg': theta_deg[idx],
            'P_inj_MW': P_inj_MW,
            'Pg_MW': Pg,
            'Pd_MW': bus['Pd']
        })
    
    df_bus = pd.DataFrame(bus_results)
    df_branch = pd.DataFrame(branch_results)
    
    # Save results
    df_bus.to_csv('case240_dc_bus_results.csv', index=False)
    df_branch.to_csv('case240_dc_branch_results.csv', index=False)
    
    # Summary
    print("\n" + "="*70)
    print("DC POWER FLOW RESULTS SUMMARY")
    print("="*70)
    
    total_gen = df_bus[df_bus['Pg_MW'] > 0]['Pg_MW'].sum()
    total_load_check = df_bus['Pd_MW'].sum()
    
    print(f"\nPower Balance:")
    print(f"  Generation: {total_gen:,.2f} MW")
    print(f"  Load:       {total_load_check:,.2f} MW")
    print(f"  Difference: {abs(total_gen - total_load_check):.2f} MW")
    print(f"  (Note: DC power flow assumes zero losses)")
    
    print(f"\nVoltage Angle Profile:")
    print(f"  Maximum angle:  {theta_deg.max():.4f}° (Bus {bus_ids[np.argmax(theta_deg)]})")
    print(f"  Minimum angle:  {theta_deg.min():.4f}° (Bus {bus_ids[np.argmin(theta_deg)]})")
    print(f"  Angle spread:   {theta_deg.max() - theta_deg.min():.4f}°")
    
    print(f"\nBranch Flow Statistics:")
    print(f"  Maximum flow:   {df_branch['P_from_MW'].abs().max():,.2f} MW")
    print(f"  Average flow:   {df_branch['P_from_MW'].abs().mean():,.2f} MW")
    
    # Find most loaded branches
    df_branch['Flow_abs'] = df_branch['P_from_MW'].abs()
    top_flows = df_branch.nlargest(10, 'Flow_abs')
    
    print(f"\nTop 10 Most Loaded Branches:")
    for _, row in top_flows.iterrows():
        print(f"  {row['From_Bus']:.0f} -> {row['To_Bus']:.0f}: {row['P_from_MW']:>10,.2f} MW " +
              f"(Δθ = {row['Angle_diff_deg']:>7.2f}°)")
    
    print(f"\nResults saved to:")
    print(f"  - case240_dc_bus_results.csv")
    print(f"  - case240_dc_branch_results.csv")
    
    print("\n" + "="*70)
    print("DC POWER FLOW ANALYSIS COMPLETED SUCCESSFULLY")
    print("="*70)
    
    print("\nDC Power Flow Assumptions:")
    print("  • All voltage magnitudes = 1.0 pu")
    print("  • Small angle approximation: sin(θ) ≈ θ")
    print("  • Series resistance neglected (R << X)")
    print("  • Reactive power ignored")
    print("  • Transmission losses = 0")
    print("  • Linear approximation of AC power flow")
    
    print("\nUse Cases:")
    print("  • Fast contingency screening")
    print("  • Preliminary system studies")
    print("  • Market clearing algorithms")
    print("  • Real-time dispatch calculations")
    print("  • Large-scale optimization problems")
    
except np.linalg.LinAlgError as e:
    print(f"\n✗ ERROR: Singular matrix - B matrix is not invertible")
    print(f"  This may indicate:")
    print(f"  - Network islands or disconnected components")
    print(f"  - Insufficient generator buses")
    print(f"  - Zero reactance branches")
    print(f"\n  Error details: {str(e)}")
    
except Exception as e:
    print(f"\n✗ ERROR: {str(e)}")
    import traceback
    traceback.print_exc()
