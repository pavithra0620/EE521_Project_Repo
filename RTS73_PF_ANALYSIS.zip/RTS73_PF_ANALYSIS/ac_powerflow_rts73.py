"""
AC Power Flow Analysis for RTS-73 System
Newton-Raphson Method (Polar Coordinates)
IEEE Reliability Test System 1996 (73 buses, 120 branches)
"""

import numpy as np
import json
import pandas as pd
from datetime import datetime

def load_case(json_file):
    """Load case data from JSON file"""
    with open(json_file, 'r') as f:
        data = json.load(f)
    return data

def build_ybus(case_data):
    """Build admittance matrix including transformer off-nominal ratios"""
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    branches = case_data['branches']
    
    n_bus = len(buses)
    bus_map = {bus['bus_i']: i for i, bus in enumerate(buses)}
    
    # Initialize Ybus
    Ybus = np.zeros((n_bus, n_bus), dtype=complex)
    
    # Add shunt admittances from buses
    for i, bus in enumerate(buses):
        Ybus[i, i] += complex(bus['Gs'], bus['Bs'])
    
    # Add branch admittances
    for branch in branches:
        if branch['status'] == 0:
            continue
            
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        r = branch['r']
        x = branch['x']
        b = branch['b']
        ratio = branch['ratio'] if branch['ratio'] != 0 else 1.0
        angle = np.radians(branch['angle'])
        
        # Series admittance
        z = complex(r, x)
        if abs(z) < 1e-10:
            y_series = complex(0, 1e10)
        else:
            y_series = 1.0 / z
        
        # Shunt admittance
        y_shunt = complex(0, b)
        
        # Transformer tap
        tap = ratio * np.exp(1j * angle)
        tap_mag_sq = abs(tap) ** 2
        
        # Build admittance contributions
        if abs(ratio - 1.0) < 1e-6 and abs(angle) < 1e-6:
            # Regular line
            Ybus[f, f] += y_series + y_shunt / 2.0
            Ybus[t, t] += y_series + y_shunt / 2.0
            Ybus[f, t] -= y_series
            Ybus[t, f] -= y_series
        else:
            # Transformer
            Ybus[f, f] += y_series / tap_mag_sq + y_shunt / 2.0
            Ybus[t, t] += y_series + y_shunt / 2.0
            Ybus[f, t] -= y_series / np.conj(tap)
            Ybus[t, f] -= y_series / tap
    
    return Ybus, bus_map

def newton_raphson_polar(case_data, max_iter=50, tol=1e-5):
    """Newton-Raphson power flow in polar coordinates"""
    
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    generators = case_data['generators']
    
    n_bus = len(buses)
    
    # Build Ybus
    Ybus, bus_map = build_ybus(case_data)
    
    # Convert to polar form
    G = np.real(Ybus)
    B = np.imag(Ybus)
    Y_mag = np.abs(Ybus)
    Y_ang = np.angle(Ybus)
    
    # Initialize voltage and power arrays - FLAT START
    V = np.ones(n_bus)
    theta = np.zeros(n_bus)
    P = np.zeros(n_bus)
    Q = np.zeros(n_bus)
    
    # Set load
    for i, bus in enumerate(buses):
        P[i] = -bus['Pd'] / baseMVA  # Load is negative injection
        Q[i] = -bus['Qd'] / baseMVA
    
    # Add generation - distribute evenly among available generators
    gen_dict = {}
    total_load_mw = sum([bus['Pd'] for bus in buses])
    
    # Find active generators
    active_gens = [gen for gen in generators if gen['status'] == 1]
    n_active_gens = len(active_gens)
    
    # Distribute generation capacity-proportionally
    total_capacity = sum([gen['Pmax'] for gen in active_gens])
    target_gen = total_load_mw * 1.10  # Assume 10% losses initially
    
    for gen in active_gens:
        bus_idx = bus_map[gen['bus']]
        if bus_idx not in gen_dict:
            gen_dict[bus_idx] = {'Pg': 0, 'Qg': 0, 'Vg': 1.0,  # Start with 1.0 pu
                                  'Qmax': 0, 'Qmin': 0}
        
        # Distribute proportionally to capacity
        gen_share = (gen['Pmax'] / total_capacity) * target_gen
        gen_dict[bus_idx]['Pg'] += gen_share / baseMVA
        gen_dict[bus_idx]['Qg'] += 0.0  # Start with zero reactive
        gen_dict[bus_idx]['Qmax'] += gen['Qmax'] / baseMVA
        gen_dict[bus_idx]['Qmin'] += gen['Qmin'] / baseMVA
    
    for bus_idx, gen_data in gen_dict.items():
        P[bus_idx] += gen_data['Pg']
        Q[bus_idx] += gen_data['Qg']
        V[bus_idx] = gen_data['Vg']  # Keep flat start voltage
    
    # Identify bus types
    pq_buses = []
    pv_buses = []
    slack_bus = None
    
    for i, bus in enumerate(buses):
        if bus['type'] == 3:  # Slack bus
            slack_bus = i
        elif bus['type'] == 2:  # PV bus
            pv_buses.append(i)
        else:  # PQ bus
            pq_buses.append(i)
    
    print(f"\n{'='*70}")
    print(f"RTS-73 AC POWER FLOW ANALYSIS")
    print(f"{'='*70}")
    print(f"Newton-Raphson Method (Polar Coordinates)")
    print(f"{'='*70}")
    print(f"\nSystem Configuration:")
    print(f"  Buses:        {n_bus}")
    print(f"  Branches:     {len(case_data['branches'])}")
    print(f"  Generators:   {len([g for g in generators if g['status'] == 1])}")
    print(f"  Base MVA:     {baseMVA}")
    print(f"\nBus Classification:")
    print(f"  Slack bus:    {slack_bus + 1} (Bus {buses[slack_bus]['bus_i']})")
    print(f"  PV buses:     {len(pv_buses)}")
    print(f"  PQ buses:     {len(pq_buses)}")
    print(f"\nInitial Conditions:")
    print(f"  Total Load:   {-sum([bus['Pd'] for bus in buses]):.2f} MW / "
          f"{-sum([bus['Qd'] for bus in buses]):.2f} MVAr")
    print(f"  Total Gen:    {sum([gen['Pg'] for gen in generators if gen['status'] == 1]):.2f} MW")
    print(f"\n{'='*70}")
    print(f"Starting Newton-Raphson Iterations...")
    print(f"{'='*70}")
    
    # Newton-Raphson iteration
    for iteration in range(max_iter):
        # Calculate injected powers
        P_calc = np.zeros(n_bus)
        Q_calc = np.zeros(n_bus)
        
        for i in range(n_bus):
            for k in range(n_bus):
                P_calc[i] += V[i] * V[k] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
                Q_calc[i] += V[i] * V[k] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # Calculate mismatches
        dP = P - P_calc
        dQ = Q - Q_calc
        
        # Build mismatch vector (exclude slack bus P, all PV Q)
        mis = []
        for i in pq_buses + pv_buses:
            mis.append(dP[i])
        for i in pq_buses:
            mis.append(dQ[i])
        
        mis = np.array(mis)
        max_mis = np.max(np.abs(mis))
        
        print(f"\nIteration {iteration + 1}:")
        print(f"  Max |ΔP|: {np.max(np.abs(dP)):.8f} pu")
        print(f"  Max |ΔQ|: {np.max(np.abs(dQ)):.8f} pu")
        print(f"  Max Mismatch: {max_mis:.8f} pu")
        
        # Check convergence
        if max_mis < tol:
            print(f"\n{'='*70}")
            print(f"✓ CONVERGED in {iteration + 1} iterations!")
            print(f"{'='*70}")
            
            # Calculate final reactive power for PV buses
            for i in pv_buses:
                Q[i] = Q_calc[i]
            
            # Update slack bus generation
            P[slack_bus] = P_calc[slack_bus]
            Q[slack_bus] = Q_calc[slack_bus]
            
            return V, theta, P, Q, P_calc, Q_calc, iteration + 1, True
        
        # Build Jacobian
        n_pq = len(pq_buses)
        n_pv = len(pv_buses)
        n_eq = n_pq + n_pv
        
        J = np.zeros((n_eq + n_pq, n_eq + n_pq))
        
        # J1: dP/dTheta
        for idx_i, i in enumerate(pq_buses + pv_buses):
            for idx_k, k in enumerate(pq_buses + pv_buses):
                if i == k:
                    J[idx_i, idx_k] = -Q_calc[i] - B[i, i] * V[i]**2
                else:
                    J[idx_i, idx_k] = V[i] * V[k] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # J2: dP/dV
        for idx_i, i in enumerate(pq_buses + pv_buses):
            for idx_k, k in enumerate(pq_buses):
                if i == k:
                    J[idx_i, n_eq + idx_k] = P_calc[i]/V[i] + G[i, i] * V[i]
                else:
                    J[idx_i, n_eq + idx_k] = V[i] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
        
        # J3: dQ/dTheta
        for idx_i, i in enumerate(pq_buses):
            for idx_k, k in enumerate(pq_buses + pv_buses):
                if i == k:
                    J[n_eq + idx_i, idx_k] = P_calc[i] - G[i, i] * V[i]**2
                else:
                    J[n_eq + idx_i, idx_k] = -V[i] * V[k] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
        
        # J4: dQ/dV
        for idx_i, i in enumerate(pq_buses):
            for idx_k, k in enumerate(pq_buses):
                if i == k:
                    J[n_eq + idx_i, n_eq + idx_k] = Q_calc[i]/V[i] - B[i, i] * V[i]
                else:
                    J[n_eq + idx_i, n_eq + idx_k] = V[i] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # Solve for corrections
        try:
            dx = np.linalg.solve(J, mis)
        except np.linalg.LinAlgError:
            print("\n✗ Jacobian is singular! Power flow did not converge.")
            return V, theta, P, Q, P_calc, Q_calc, iteration + 1, False
        
        # Update state variables
        for idx, i in enumerate(pq_buses + pv_buses):
            theta[i] += dx[idx]
        
        for idx, i in enumerate(pq_buses):
            V[i] += dx[n_eq + idx]
    
    print(f"\n{'='*70}")
    print(f"✗ Did not converge in {max_iter} iterations")
    print(f"{'='*70}")
    return V, theta, P, Q, P_calc, Q_calc, max_iter, False

def analyze_results(case_data, V, theta, P, Q, P_calc, Q_calc):
    """Analyze and display power flow results"""
    
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    branches = case_data['branches']
    generators = case_data['generators']
    
    n_bus = len(buses)
    bus_map = {bus['bus_i']: i for i, bus in enumerate(buses)}
    
    print(f"\n{'='*70}")
    print(f"POWER FLOW RESULTS")
    print(f"{'='*70}")
    
    # Bus results
    bus_results = []
    for i, bus in enumerate(buses):
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'V (pu)': V[i],
            'Angle (deg)': np.degrees(theta[i]),
            'P_gen (MW)': 0.0,
            'Q_gen (MVAr)': 0.0,
            'P_load (MW)': bus['Pd'],
            'Q_load (MVAr)': bus['Qd'],
            'P_inj (MW)': P_calc[i] * baseMVA,
            'Q_inj (MVAr)': Q_calc[i] * baseMVA
        })
    
    # Add generation data
    for gen in generators:
        if gen['status'] == 1:
            bus_idx = bus_map[gen['bus']]
            bus_results[bus_idx]['P_gen'] += gen['Pg']
            bus_results[bus_idx]['Q_gen'] += gen['Qg']
    
    # Update slack bus generation
    slack_idx = next(i for i, bus in enumerate(buses) if bus['type'] == 3)
    bus_results[slack_idx]['P_gen'] = P_calc[slack_idx] * baseMVA + bus_results[slack_idx]['P_load']
    bus_results[slack_idx]['Q_gen'] = Q_calc[slack_idx] * baseMVA + bus_results[slack_idx]['Q_load']
    
    df_bus = pd.DataFrame(bus_results)
    
    # System summary
    total_gen_p = df_bus['P_gen'].sum()
    total_gen_q = df_bus['Q_gen'].sum()
    total_load_p = df_bus['P_load'].sum()
    total_load_q = df_bus['Q_load'].sum()
    total_loss_p = total_gen_p - total_load_p
    total_loss_q = total_gen_q - total_load_q
    
    print(f"\nSystem Power Balance:")
    print(f"  Total Generation:  {total_gen_p:,.2f} MW / {total_gen_q:,.2f} MVAr")
    print(f"  Total Load:        {total_load_p:,.2f} MW / {total_load_q:,.2f} MVAr")
    print(f"  Total Losses:      {total_loss_p:,.2f} MW / {total_loss_q:,.2f} MVAr")
    print(f"  Loss Percentage:   {100*total_loss_p/total_gen_p:.2f}%")
    
    # Voltage profile
    print(f"\nVoltage Profile:")
    print(f"  Min Voltage:  {V.min():.4f} pu at Bus {buses[V.argmin()]['bus_i']}")
    print(f"  Max Voltage:  {V.max():.4f} pu at Bus {buses[V.argmax()]['bus_i']}")
    
    violations = []
    for i, bus in enumerate(buses):
        if V[i] < bus['Vmin'] or V[i] > bus['Vmax']:
            violations.append({
                'Bus': bus['bus_i'],
                'V_actual': V[i],
                'V_min': bus['Vmin'],
                'V_max': bus['Vmax']
            })
    
    print(f"  Violations:   {len(violations)} buses")
    
    # Branch flows
    branch_results = []
    Ybus, _ = build_ybus(case_data)
    
    for idx, branch in enumerate(branches):
        if branch['status'] == 0:
            continue
            
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        r = branch['r']
        x = branch['x']
        b = branch['b']
        ratio = branch['ratio'] if branch['ratio'] != 0 else 1.0
        angle = np.radians(branch['angle'])
        
        z = complex(r, x)
        if abs(z) < 1e-10:
            y_series = complex(0, 1e10)
        else:
            y_series = 1.0 / z
        y_shunt = complex(0, b)
        
        tap = ratio * np.exp(1j * angle)
        
        Vf = V[f] * np.exp(1j * theta[f])
        Vt = V[t] * np.exp(1j * theta[t])
        
        tap_mag_sq = abs(tap) ** 2
        
        if abs(ratio - 1.0) < 1e-6 and abs(angle) < 1e-6:
            If = y_series * (Vf - Vt) + (y_shunt / 2.0) * Vf
            It = y_series * (Vt - Vf) + (y_shunt / 2.0) * Vt
        else:
            If = (y_series / tap_mag_sq) * Vf - (y_series / np.conj(tap)) * Vt + (y_shunt / 2.0) * Vf
            It = y_series * Vt - (y_series / tap) * Vf + (y_shunt / 2.0) * Vt
        
        Sf = Vf * np.conj(If) * baseMVA
        St = Vt * np.conj(It) * baseMVA
        
        Pf = np.real(Sf)
        Qf = np.imag(Sf)
        Pt = np.real(St)
        Qt = np.imag(St)
        
        P_loss = Pf + Pt
        Q_loss = Qf + Qt
        
        loading = max(abs(Sf), abs(St)) / branch['rateA'] * 100 if branch['rateA'] > 0 else 0
        
        branch_results.append({
            'From': branch['fbus'],
            'To': branch['tbus'],
            'P_from (MW)': Pf,
            'Q_from (MVAr)': Qf,
            'P_to (MW)': Pt,
            'Q_to (MVAr)': Qt,
            'P_loss (MW)': P_loss,
            'Q_loss (MVAr)': Q_loss,
            'S_from (MVA)': abs(Sf),
            'S_to (MVA)': abs(St),
            'Rating (MVA)': branch['rateA'],
            'Loading (%)': loading
        })
    
    df_branch = pd.DataFrame(branch_results)
    
    # Branch loading analysis
    overloaded = df_branch[df_branch['Loading (%)'] > 100]
    print(f"\nBranch Loading:")
    print(f"  Max Loading:   {df_branch['Loading (%)'].max():.2f}% "
          f"(Bus {int(df_branch.loc[df_branch['Loading (%)'].idxmax(), 'From'])} -> "
          f"Bus {int(df_branch.loc[df_branch['Loading (%)'].idxmax(), 'To'])})")
    print(f"  Overloaded:    {len(overloaded)} branches")
    
    print(f"\n{'='*70}")
    
    return df_bus, df_branch

# Main execution
if __name__ == "__main__":
    print(f"\nAC Power Flow Analysis - RTS-73 System")
    print(f"Analysis started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Load case
    case_data = load_case('rts73.json')
    
    # Run power flow
    V, theta, P, Q, P_calc, Q_calc, iterations, converged = newton_raphson_polar(
        case_data, max_iter=20, tol=1e-6
    )
    
    if converged:
        # Analyze results
        df_bus, df_branch = analyze_results(case_data, V, theta, P, Q, P_calc, Q_calc)
        
        # Save results
        df_bus.to_csv('rts73_bus_results.csv', index=False)
        df_branch.to_csv('rts73_branch_results.csv', index=False)
        
        print(f"\n✓ Results saved:")
        print(f"  - rts73_bus_results.csv")
        print(f"  - rts73_branch_results.csv")
    else:
        print(f"\n✗ Power flow did not converge")
    
    print(f"\nAnalysis completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")
