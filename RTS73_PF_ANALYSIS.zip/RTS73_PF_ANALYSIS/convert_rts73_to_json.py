"""
Convert RTS-73 MATPOWER case to JSON format
IEEE Reliability Test System 1996 (73 buses)
"""

import re
import json

def parse_matpower_case_rts73(filename):
    """Parse RTS-73 MATPOWER case file"""
    
    with open(filename, 'r') as f:
        content = f.read()
    
    # Extract baseMVA
    basemva_match = re.search(r'mpc\.baseMVA\s*=\s*([0-9.]+)', content)
    baseMVA = float(basemva_match.group(1)) if basemva_match else 100.0
    
    # Extract bus data
    bus_pattern = r'mpc\.bus\s*=\s*\[(.*?)\];'
    bus_match = re.search(bus_pattern, content, re.DOTALL)
    
    buses = []
    if bus_match:
        bus_lines = bus_match.group(1).strip().split('\n')
        for line in bus_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                # Remove comments
                line = re.sub(r'%.*$', '', line).strip()
                if line.endswith(';'):
                    line = line[:-1]
                
                parts = line.split()
                if len(parts) >= 13:
                    bus = {
                        'bus_i': int(parts[0]),
                        'type': int(parts[1]),
                        'Pd': float(parts[2]),
                        'Qd': float(parts[3]),
                        'Gs': float(parts[4]),
                        'Bs': float(parts[5]),
                        'area': int(parts[6]),
                        'Vm': float(parts[7]),
                        'Va': float(parts[8]),
                        'baseKV': float(parts[9]),
                        'zone': int(parts[10]),
                        'Vmax': float(parts[11]),
                        'Vmin': float(parts[12])
                    }
                    buses.append(bus)
    
    # Extract generator data
    gen_pattern = r'mpc\.gen\s*=\s*\[(.*?)\];'
    gen_match = re.search(gen_pattern, content, re.DOTALL)
    
    generators = []
    if gen_match:
        gen_lines = gen_match.group(1).strip().split('\n')
        for line in gen_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                line = re.sub(r'%.*$', '', line).strip()
                if line.endswith(';'):
                    line = line[:-1]
                
                parts = line.split()
                if len(parts) >= 10:
                    gen = {
                        'bus': int(parts[0]),
                        'Pg': float(parts[1]),
                        'Qg': float(parts[2]),
                        'Qmax': float(parts[3]),
                        'Qmin': float(parts[4]),
                        'Vg': float(parts[5]),
                        'mBase': float(parts[6]),
                        'status': int(parts[7]),
                        'Pmax': float(parts[8]),
                        'Pmin': float(parts[9])
                    }
                    generators.append(gen)
    
    # Extract branch data
    branch_pattern = r'mpc\.branch\s*=\s*\[(.*?)\];'
    branch_match = re.search(branch_pattern, content, re.DOTALL)
    
    branches = []
    if branch_match:
        branch_lines = branch_match.group(1).strip().split('\n')
        for line in branch_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                line = re.sub(r'%.*$', '', line).strip()
                if line.endswith(';'):
                    line = line[:-1]
                
                parts = line.split()
                if len(parts) >= 13:
                    branch = {
                        'fbus': int(parts[0]),
                        'tbus': int(parts[1]),
                        'r': float(parts[2]),
                        'x': float(parts[3]),
                        'b': float(parts[4]),
                        'rateA': float(parts[5]),
                        'rateB': float(parts[6]),
                        'rateC': float(parts[7]),
                        'ratio': float(parts[8]),
                        'angle': float(parts[9]),
                        'status': int(parts[10]),
                        'angmin': float(parts[11]),
                        'angmax': float(parts[12])
                    }
                    branches.append(branch)
    
    return {
        'version': '2',
        'baseMVA': baseMVA,
        'buses': buses,
        'generators': generators,
        'branches': branches
    }

print("="*70)
print("CONVERTING RTS-73 TO JSON FORMAT")
print("="*70)

# Parse the MATPOWER file
case_data = parse_matpower_case_rts73('rts73.txt')

print(f"\nParsed RTS-73 System:")
print(f"  Base MVA:    {case_data['baseMVA']}")
print(f"  Buses:       {len(case_data['buses'])}")
print(f"  Generators:  {len(case_data['generators'])}")
print(f"  Branches:    {len(case_data['branches'])}")

# Calculate system totals
total_load_p = sum([bus['Pd'] for bus in case_data['buses']])
total_load_q = sum([bus['Qd'] for bus in case_data['buses']])
total_gen_p = sum([gen['Pg'] for gen in case_data['generators'] if gen['status'] == 1])
total_gen_cap = sum([gen['Pmax'] for gen in case_data['generators'] if gen['status'] == 1])

print(f"\nSystem Summary:")
print(f"  Total Load:        {total_load_p:,.2f} MW / {total_load_q:,.2f} MVAr")
print(f"  Total Generation:  {total_gen_p:,.2f} MW")
print(f"  Gen Capacity:      {total_gen_cap:,.2f} MW")

# Save to JSON
with open('rts73.json', 'w') as f:
    json.dump(case_data, f, indent=2)

print(f"\n✓ JSON file saved: rts73.json")
print("="*70)
