"""
DC Power Flow Analysis for RTS-73 System
Linear approximation method using B-matrix
IEEE Reliability Test System 1996 (73 buses, 120 branches)
"""

import numpy as np
import json
import pandas as pd
from datetime import datetime

def load_case(json_file):
    """Load case data from JSON file"""
    with open(json_file, 'r') as f:
        data = json.load(f)
    return data

def dc_powerflow(case_data):
    """DC power flow using B-matrix method"""
    
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    branches = case_data['branches']
    generators = case_data['generators']
    
    n_bus = len(buses)
    bus_map = {bus['bus_i']: i for i, bus in enumerate(buses)}
    
    print(f"\n{'='*70}")
    print(f"RTS-73 DC POWER FLOW ANALYSIS")
    print(f"{'='*70}")
    print(f"\nSystem Configuration:")
    print(f"  Buses:       {n_bus}")
    print(f"  Branches:    {len(branches)}")
    print(f"  Generators:  {len([g for g in generators if g['status'] == 1])}")
    print(f"  Base MVA:    {baseMVA}")
    
    # Build B matrix (susceptance matrix)
    B = np.zeros((n_bus, n_bus))
    
    for branch in branches:
        if branch['status'] == 0:
            continue
        
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        x = branch['x']
        
        if abs(x) < 1e-8:
            b = 1e8
        else:
            b = 1.0 / x
        
        B[f, f] += b
        B[t, t] += b
        B[f, t] -= b
        B[t, f] -= b
    
    # Net power injections
    P = np.zeros(n_bus)
    
    # Load
    for i, bus in enumerate(buses):
        P[i] = -bus['Pd'] / baseMVA
    
    # Generation - distribute proportionally
    total_load_mw = sum([bus['Pd'] for bus in buses])
    active_gens = [gen for gen in generators if gen['status'] == 1]
    total_capacity = sum([gen['Pmax'] for gen in active_gens])
    
    for gen in active_gens:
        bus_idx = bus_map[gen['bus']]
        gen_share = (gen['Pmax'] / total_capacity) * total_load_mw
        P[bus_idx] += gen_share / baseMVA
    
    # Identify slack bus
    slack_bus = None
    for i, bus in enumerate(buses):
        if bus['type'] == 3:
            slack_bus = i
            break
    
    print(f"\nSlack Bus: {buses[slack_bus]['bus_i']}")
    print(f"Total Load: {total_load_mw:.2f} MW")
    
    # Reduce system (remove slack bus)
    B_reduced = np.delete(np.delete(B, slack_bus, 0), slack_bus, 1)
    P_reduced = np.delete(P, slack_bus)
    
    # Solve for voltage angles
    try:
        theta_reduced = np.linalg.solve(B_reduced, P_reduced)
    except np.linalg.LinAlgError:
        print("\n✗ B-matrix is singular! DC power flow failed.")
        return None, None, None, False
    
    # Insert slack bus angle (reference = 0)
    theta = np.insert(theta_reduced, slack_bus, 0.0)
    
    print(f"\n{'='*70}")
    print(f"DC POWER FLOW SOLUTION")
    print(f"{'='*70}")
    
    # Calculate branch flows
    branch_flows = []
    total_loss = 0.0
    
    for branch in branches:
        if branch['status'] == 0:
            continue
        
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        x = branch['x']
        b = 1.0 / x if abs(x) > 1e-8 else 1e8
        
        # Power flow from f to t
        P_ft = b * (theta[f] - theta[t]) * baseMVA
        
        branch_flows.append({
            'From': branch['fbus'],
            'To': branch['tbus'],
            'P_flow (MW)': P_ft,
            'X (pu)': x,
            'Angle_diff (deg)': np.degrees(theta[f] - theta[t]),
            'Rating (MVA)': branch['rateA'],
            'Loading (%)': abs(P_ft) / branch['rateA'] * 100 if branch['rateA'] > 0 else 0
        })
    
    df_branch = pd.DataFrame(branch_flows)
    
    # Bus results with generation
    bus_results = []
    gen_dict = {}
    
    for gen in active_gens:
        bus_idx = bus_map[gen['bus']]
        if bus_idx not in gen_dict:
            gen_dict[bus_idx] = 0
        gen_share = (gen['Pmax'] / total_capacity) * total_load_mw
        gen_dict[bus_idx] += gen_share
    
    # Calculate actual generation including slack
    for i, bus in enumerate(buses):
        # Calculate net injection from branch flows
        net_injection = 0
        for _, branch_row in df_branch.iterrows():
            if branch_row['From'] == bus['bus_i']:
                net_injection -= branch_row['P_flow (MW)']
            elif branch_row['To'] == bus['bus_i']:
                net_injection += branch_row['P_flow (MW)']
        
        gen_mw = gen_dict.get(i, 0)
        if i == slack_bus:
            # Slack picks up the balance
            gen_mw = net_injection + bus['Pd']
        
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'Angle (deg)': np.degrees(theta[i]),
            'P_gen (MW)': gen_mw,
            'P_load (MW)': bus['Pd'],
            'P_net (MW)': net_injection
        })
    
    df_bus = pd.DataFrame(bus_results)
    
    # Summary
    total_gen = df_bus['P_gen (MW)'].sum()
    total_load = df_bus['P_load (MW)'].sum()
    total_loss = total_gen - total_load
    
    print(f"\nPower Balance:")
    print(f"  Total Generation:  {total_gen:,.2f} MW")
    print(f"  Total Load:        {total_load:,.2f} MW")
    print(f"  Total Losses:      {total_loss:,.2f} MW")
    print(f"  Loss % (apparent): {100*total_loss/total_gen:.2f}%")
    print(f"\nNote: DC power flow assumes zero losses (linearization)")
    print(f"      Apparent losses are numerical artifacts")
    
    # Angle spread
    theta_deg = np.degrees(theta)
    print(f"\nVoltage Angle Profile:")
    print(f"  Min Angle:  {theta_deg.min():+.2f}° (Bus {buses[theta_deg.argmin()]['bus_i']})")
    print(f"  Max Angle:  {theta_deg.max():+.2f}° (Bus {buses[theta_deg.argmax()]['bus_i']})")
    print(f"  Angle Span: {theta_deg.max() - theta_deg.min():.2f}°")
    
    # Branch loading
    max_loading_idx = df_branch['Loading (%)'].idxmax()
    max_loading_branch = df_branch.loc[max_loading_idx]
    
    print(f"\nBranch Loading:")
    print(f"  Max Loading: {max_loading_branch['Loading (%)']:.2f}% "
          f"(Bus {int(max_loading_branch['From'])} → Bus {int(max_loading_branch['To'])})")
    
    overloaded = df_branch[df_branch['Loading (%)'] > 100]
    print(f"  Overloaded:  {len(overloaded)} branches")
    
    if len(overloaded) > 0:
        print(f"\n  Overloaded Branches:")
        for _, branch in overloaded.head(10).iterrows():
            print(f"    Bus {int(branch['From']):3d} → {int(branch['To']):3d}: "
                  f"{branch['Loading (%)']:6.2f}% ({branch['P_flow (MW)']:7.2f} MW)")
    
    print(f"\n{'='*70}")
    print(f"✓ DC POWER FLOW COMPLETED")
    print(f"{'='*70}")
    
    return df_bus, df_branch, theta, True

# Main execution
if __name__ == "__main__":
    print(f"\nDC Power Flow Analysis - RTS-73 System")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Load case
    case_data = load_case('rts73.json')
    
    # Run DC power flow
    df_bus, df_branch, theta, success = dc_powerflow(case_data)
    
    if success:
        # Save results
        df_bus.to_csv('rts73_dc_bus_results.csv', index=False)
        df_branch.to_csv('rts73_dc_branch_results.csv', index=False)
        
        print(f"\n✓ Results saved:")
        print(f"  • rts73_dc_bus_results.csv ({len(df_bus)} buses)")
        print(f"  • rts73_dc_branch_results.csv ({len(df_branch)} branches)")
    else:
        print(f"\n✗ DC power flow failed")
    
    print(f"\nCompleted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")
