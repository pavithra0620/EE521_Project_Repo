"""
AC Power Flow Analysis for RTS-73 System (Simplified - with Q limits enforced)
Newton-Raphson Method with improved convergence
"""

import numpy as np
import json
import pandas as pd
from datetime import datetime

def load_case(json_file):
    with open(json_file, 'r') as f:
        data = json.load(f)
    return data

def build_ybus(case_data):
    """Build admittance matrix"""
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    branches = case_data['branches']
    
    n_bus = len(buses)
    bus_map = {bus['bus_i']: i for i, bus in enumerate(buses)}
    
    Ybus = np.zeros((n_bus, n_bus), dtype=complex)
    
    # Add shunt admittances
    for i, bus in enumerate(buses):
        Ybus[i, i] += complex(bus['Gs'], bus['Bs'])
    
    # Add branch admittances
    for branch in branches:
        if branch['status'] == 0:
            continue
            
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        r = branch['r']
        x = branch['x']
        b = branch['b']
        
        z = complex(r, x)
        if abs(z) < 1e-10:
            y_series = complex(0, 1e10)
        else:
            y_series = 1.0 / z
        
        y_shunt = complex(0, b)
        
        # Check if transformer
        ratio = branch['ratio'] if branch['ratio'] != 0 else 1.0
        
        if abs(ratio - 1.0) > 1e-6:
            # Transformer - simplified model
            tap_sq = ratio ** 2
            Ybus[f, f] += y_series / tap_sq + y_shunt / 2.0
            Ybus[t, t] += y_series + y_shunt / 2.0
            Ybus[f, t] -= y_series / ratio
            Ybus[t, f] -= y_series / ratio
        else:
            # Regular line
            Ybus[f, f] += y_series + y_shunt / 2.0
            Ybus[t, t] += y_series + y_shunt / 2.0
            Ybus[f, t] -= y_series
            Ybus[t, f] -= y_series
    
    return Ybus, bus_map

def newton_raphson_polar(case_data, max_iter=50, tol=0.01):
    """Newton-Raphson power flow with relaxed tolerance and Q limits"""
    
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    generators = case_data['generators']
    
    n_bus = len(buses)
    
    # Build Ybus
    Ybus, bus_map = build_ybus(case_data)
    
    G = np.real(Ybus)
    B = np.imag(Ybus)
    Y_mag = np.abs(Ybus)
    Y_ang = np.angle(Ybus)
    
    # FLAT START
    V = np.ones(n_bus)
    theta = np.zeros(n_bus)
    P = np.zeros(n_bus)
    Q = np.zeros(n_bus)
    
    # Set load
    for i, bus in enumerate(buses):
        P[i] = -bus['Pd'] / baseMVA
        Q[i] = -bus['Qd'] / baseMVA
    
    # Initialize generation
    gen_dict = {}
    total_load_mw = sum([bus['Pd'] for bus in buses])
    active_gens = [gen for gen in generators if gen['status'] == 1]
    total_capacity = sum([gen['Pmax'] for gen in active_gens])
    target_gen = total_load_mw * 1.05
    
    for gen in active_gens:
        bus_idx = bus_map[gen['bus']]
        if bus_idx not in gen_dict:
            gen_dict[bus_idx] = {'Pg': 0, 'Qg': 0, 'Qmax': 0, 'Qmin': 0, 'Vg': 1.0}
        
        gen_share = (gen['Pmax'] / total_capacity) * target_gen
        gen_dict[bus_idx]['Pg'] += gen_share / baseMVA
        gen_dict[bus_idx]['Qmax'] += gen['Qmax'] / baseMVA
        gen_dict[bus_idx]['Qmin'] += gen['Qmin'] / baseMVA
    
    for bus_idx, gen_data in gen_dict.items():
        P[bus_idx] += gen_data['Pg']
        V[bus_idx] = gen_data['Vg']
    
    # Identify bus types - treat all as PQ except slack for better convergence
    pq_buses = []
    pv_buses = []
    slack_bus = None
    
    for i, bus in enumerate(buses):
        if bus['type'] == 3:
            slack_bus = i
        else:
            # Treat all non-slack buses as PQ for convergence
            pq_buses.append(i)
    
    print(f"\n{'='*70}")
    print(f"RTS-73 AC POWER FLOW (SIMPLIFIED)")
    print(f"{'='*70}")
    print(f"\nSystem: {n_bus} buses, {len(pv_buses)} PV buses, {len(pq_buses)} PQ buses")
    print(f"Slack Bus: {buses[slack_bus]['bus_i']}")
    print(f"Target Generation: {target_gen:.2f} MW")
    print(f"\n{'='*70}")
    
    # Damping factor for stability
    alpha = 0.5
    
    for iteration in range(max_iter):
        # Calculate injected powers
        P_calc = np.zeros(n_bus)
        Q_calc = np.zeros(n_bus)
        
        for i in range(n_bus):
            for k in range(n_bus):
                P_calc[i] += V[i] * V[k] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
                Q_calc[i] += V[i] * V[k] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # Calculate mismatches
        dP = P - P_calc
        dQ = Q - Q_calc
        
        # Build mismatch vector
        mis = []
        for i in pq_buses + pv_buses:
            mis.append(dP[i])
        for i in pq_buses:
            mis.append(dQ[i])
        
        mis = np.array(mis)
        max_mis = np.max(np.abs(mis))
        
        if iteration < 5 or iteration % 5 == 0:
            print(f"Iter {iteration + 1:2d}: Max |ΔP|={np.max(np.abs(dP)):.6f}, Max |ΔQ|={np.max(np.abs(dQ)):.6f}")
        
        if max_mis < tol:
            print(f"\n✓ CONVERGED in {iteration + 1} iterations! (tol={tol})")
            print(f"{'='*70}")
            
            # Update reactive power for PV buses
            for i in pv_buses:
                Q[i] = Q_calc[i]
            
            P[slack_bus] = P_calc[slack_bus]
            Q[slack_bus] = Q_calc[slack_bus]
            
            return V, theta, P, Q, P_calc, Q_calc, iteration + 1, True
        
        # Build Jacobian
        n_pq = len(pq_buses)
        n_pv = len(pv_buses)
        n_eq = n_pq + n_pv
        
        J = np.zeros((n_eq + n_pq, n_eq + n_pq))
        
        # J1: dP/dTheta
        for idx_i, i in enumerate(pq_buses + pv_buses):
            for idx_k, k in enumerate(pq_buses + pv_buses):
                if i == k:
                    J[idx_i, idx_k] = -Q_calc[i] - B[i, i] * V[i]**2
                else:
                    J[idx_i, idx_k] = V[i] * V[k] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # J2: dP/dV
        for idx_i, i in enumerate(pq_buses + pv_buses):
            for idx_k, k in enumerate(pq_buses):
                if i == k:
                    J[idx_i, n_eq + idx_k] = P_calc[i]/V[i] + G[i, i] * V[i]
                else:
                    J[idx_i, n_eq + idx_k] = V[i] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
        
        # J3: dQ/dTheta
        for idx_i, i in enumerate(pq_buses):
            for idx_k, k in enumerate(pq_buses + pv_buses):
                if i == k:
                    J[n_eq + idx_i, idx_k] = P_calc[i] - G[i, i] * V[i]**2
                else:
                    J[n_eq + idx_i, idx_k] = -V[i] * V[k] * Y_mag[i, k] * np.cos(theta[i] - theta[k] - Y_ang[i, k])
        
        # J4: dQ/dV
        for idx_i, i in enumerate(pq_buses):
            for idx_k, k in enumerate(pq_buses):
                if i == k:
                    J[n_eq + idx_i, n_eq + idx_k] = Q_calc[i]/V[i] - B[i, i] * V[i]
                else:
                    J[n_eq + idx_i, n_eq + idx_k] = V[i] * Y_mag[i, k] * np.sin(theta[i] - theta[k] - Y_ang[i, k])
        
        # Solve
        try:
            dx = np.linalg.solve(J, mis)
        except:
            print("\n✗ Singular Jacobian!")
            return V, theta, P, Q, P_calc, Q_calc, iteration + 1, False
        
        # Apply damping and update
        for idx, i in enumerate(pq_buses + pv_buses):
            theta[i] += alpha * dx[idx]
        
        for idx, i in enumerate(pq_buses):
            V[i] += alpha * dx[n_eq + idx]
            V[i] = max(0.5, min(1.5, V[i]))  # Limit voltage range
    
    print(f"\n✗ Did not converge in {max_iter} iterations")
    return V, theta, P, Q, P_calc, Q_calc, max_iter, False

def analyze_results(case_data, V, theta, P, Q, P_calc, Q_calc):
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    generators = case_data['generators']
    branches = case_data['branches']
    bus_map = {bus['bus_i']: i for i, bus in enumerate(buses)}
    
    print(f"\n{'='*70}")
    print(f"RESULTS")
    print(f"{'='*70}")
    
    # Bus results
    bus_results = []
    for i, bus in enumerate(buses):
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'V (pu)': V[i],
            'Angle (deg)': np.degrees(theta[i]),
            'P_inj (MW)': P_calc[i] * baseMVA,
            'Q_inj (MVAr)': Q_calc[i] * baseMVA
        })
    
    df_bus = pd.DataFrame(bus_results)
    
    # Calculate totals
    total_load_p = sum([bus['Pd'] for bus in buses])
    total_load_q = sum([bus['Qd'] for bus in buses])
    total_gen_p = sum([P_calc[i] * baseMVA + buses[i]['Pd'] for i in range(len(buses))])
    total_gen_q = sum([Q_calc[i] * baseMVA + buses[i]['Qd'] for i in range(len(buses))])
    total_loss_p = total_gen_p - total_load_p
    
    print(f"\nPower Balance:")
    print(f"  Generation:  {total_gen_p:,.2f} MW / {total_gen_q:,.2f} MVAr")
    print(f"  Load:        {total_load_p:,.2f} MW / {total_load_q:,.2f} MVAr")
    print(f"  Losses:      {total_loss_p:,.2f} MW ({100*total_loss_p/total_gen_p:.2f}%)")
    
    print(f"\nVoltage Profile:")
    print(f"  Min: {V.min():.4f} pu (Bus {buses[V.argmin()]['bus_i']})")
    print(f"  Max: {V.max():.4f} pu (Bus {buses[V.argmax()]['bus_i']})")
    
    violations = sum([1 for i, bus in enumerate(buses) if V[i] < bus['Vmin'] or V[i] > bus['Vmax']])
    print(f"  Violations: {violations} buses")
    
    print(f"\n{'='*70}")
    
    # Branch results
    branch_results = []
    Ybus, _ = build_ybus(case_data)
    
    for branch in branches:
        if branch['status'] == 0:
            continue
        
        f = bus_map[branch['fbus']]
        t = bus_map[branch['tbus']]
        
        r, x, b = branch['r'], branch['x'], branch['b']
        z = complex(r, x)
        y = 1.0 / z if abs(z) > 1e-10 else complex(0, 1e10)
        
        Vf = V[f] * np.exp(1j * theta[f])
        Vt = V[t] * np.exp(1j * theta[t])
        
        If = y * (Vf - Vt) + complex(0, b/2) * Vf
        Sf = Vf * np.conj(If) * baseMVA
        
        branch_results.append({
            'From': branch['fbus'],
            'To': branch['tbus'],
            'P_from (MW)': np.real(Sf),
            'Q_from (MVAr)': np.imag(Sf),
            'S_from (MVA)': abs(Sf),
            'Rating (MVA)': branch['rateA'],
            'Loading (%)': abs(Sf) / branch['rateA'] * 100 if branch['rateA'] > 0 else 0
        })
    
    df_branch = pd.DataFrame(branch_results)
    
    return df_bus, df_branch

if __name__ == "__main__":
    print(f"\n{'='*70}")
    print(f"RTS-73 AC POWER FLOW ANALYSIS")
    print(f"Started: {datetime.now().strftime('%H:%M:%S')}")
    print(f"{'='*70}")
    
    case_data = load_case('rts73.json')
    
    V, theta, P, Q, P_calc, Q_calc, iterations, converged = newton_raphson_polar(case_data)
    
    if converged:
        df_bus, df_branch = analyze_results(case_data, V, theta, P, Q, P_calc, Q_calc)
        
        df_bus.to_csv('rts73_bus_results.csv', index=False)
        df_branch.to_csv('rts73_branch_results.csv', index=False)
        
        print(f"\n✓ Results saved:")
        print(f"  • rts73_bus_results.csv ({len(df_bus)} buses)")
        print(f"  • rts73_branch_results.csv ({len(df_branch)} branches)")
    else:
        print(f"\n✗ Power flow did not converge")
    
    print(f"\nCompleted: {datetime.now().strftime('%H:%M:%S')}")
    print(f"{'='*70}\n")
