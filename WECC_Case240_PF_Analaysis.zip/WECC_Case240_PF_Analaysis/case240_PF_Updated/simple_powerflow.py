"""
Simple Power Flow with Flat Start - Maximum Convergence Focus
"""

import json
import numpy as np
import pandas as pd
from NR_polar import NR_polar

print("="*70)
print("SIMPLE POWER FLOW ANALYSIS - Case 240 (Flat Start)")
print("="*70)

# Load case
with open('case240.json', 'r') as f:
    case_data = json.load(f)

baseMVA = case_data['baseMVA']
buses = case_data['buses']
branches = case_data['branches']
generators = case_data['generators']

print(f"\nSystem: {len(buses)} buses, {len(branches)} branches, {len(generators)} generators")

# Build Y-bus
print("\nBuilding Y-bus...")
n_buses = len(buses)
bus_ids = [bus['bus_i'] for bus in buses]
bus_idx_map = {bus_id: idx for idx, bus_id in enumerate(bus_ids)}

Y = np.zeros((n_buses, n_buses), dtype=complex)

for branch in branches:
    if branch['status'] == 0:
        continue
    
    i = bus_idx_map[branch['fbus']]
    j = bus_idx_map[branch['tbus']]
    
    r, x, b = branch['r'], branch['x'], branch['b']
    
    if abs(r + 1j*x) > 1e-10:
        y = 1.0 / (r + 1j * x)
    else:
        continue
    
    y_shunt = 1j * b / 2.0
    
    Y[i, i] += y + y_shunt
    Y[j, j] += y + y_shunt
    Y[i, j] -= y
    Y[j, i] -= y

print("Y-bus built successfully")

# Calculate total load
total_load = sum([bus['Pd'] for bus in buses])
print(f"Total load: {total_load:,.2f} MW")

# Scale generation to match load + 5% losses
total_gen_capacity = sum([gen['Pg'] for gen in generators if gen['status'] == 1])
scale = (total_load * 1.05) / total_gen_capacity if total_gen_capacity > 0 else 1.0

print(f"Scaling generation by {scale:.4f}")

# Setup power injections
gen_map = {}
for gen in generators:
    if gen['status'] == 1:
        idx = bus_idx_map[gen['bus']]
        if idx not in gen_map:
            gen_map[idx] = 0.0
        gen_map[idx] += gen['Pg'] * scale

S_star = np.zeros(n_buses, dtype=complex)
for idx, bus in enumerate(buses):
    Pg = gen_map.get(idx, 0.0) / baseMVA
    Pd = bus['Pd'] / baseMVA
    Qd = bus['Qd'] / baseMVA
    S_star[idx] = (Pg - Pd) - 1j * Qd  # Start with zero Q generation

# Classify buses
idx_slack, idx_pv, idx_pq = [], [], []
for idx, bus in enumerate(buses):
    if bus['type'] == 3:
        idx_slack.append(idx)
    elif bus['type'] == 2:
        idx_pv.append(idx)
    else:
        idx_pq.append(idx)

if not idx_slack:
    idx_slack = [idx_pv[0]]
    idx_pv = idx_pv[1:]

idx_slack = np.array(idx_slack)
idx_pv = np.array(idx_pv)
idx_pq = np.array(idx_pq)

print(f"\nBuses: {len(idx_slack)} slack, {len(idx_pv)} PV, {len(idx_pq)} PQ")

# Flat start: all voltages at 1.0 pu, 0 degrees
E_0 = np.ones(n_buses, dtype=complex)
E_star = np.ones(n_buses)

# Run NR with very relaxed settings
print("\nRunning Newton-Raphson...")
print("Settings: tolerance=1e-3, max_iter=200")

try:
    E, S, J, n_iter = NR_polar(Y, S_star, E_star, E_0, 
                               idx_slack[0], idx_pq, idx_pv, 
                               1e-3, 200)
    
    # Check convergence
    I = Y @ E
    S_calc = E * np.conj(I)
    dS = S_star - S_calc
    dP = np.delete(np.real(dS), idx_slack)
    dQ = np.delete(np.imag(dS), np.sort(np.concatenate([idx_pv, [idx_slack[0]]])))
    max_mismatch = max(np.max(np.abs(dP)), np.max(np.abs(dQ)))
    
    converged = n_iter < 200
    
    print(f"\nResult: {'CONVERGED' if converged else 'MAX ITERATIONS'}")
    print(f"Iterations: {n_iter}")
    print(f"Max mismatch: {max_mismatch:.2e} pu")
    
    # Calculate results
    V_mag = np.abs(E)
    V_ang = np.angle(E, deg=True)
    S_pu = S
    
    # Bus results
    bus_results = []
    for idx, bus in enumerate(buses):
        S_mva = S_pu[idx] * baseMVA
        Pg = gen_map.get(idx, 0.0)
        Qg = S_mva.imag + bus['Qd']
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'V_mag_pu': V_mag[idx],
            'V_ang_deg': V_ang[idx],
            'P_inj_MW': S_mva.real,
            'Q_inj_MVAr': S_mva.imag,
            'Pg_MW': Pg,
            'Qg_MVAr': Qg,
            'Pd_MW': bus['Pd'],
            'Qd_MVAr': bus['Qd']
        })
    
    # Branch results
    branch_results = []
    for branch in branches:
        if branch['status'] == 0:
            continue
        i = bus_idx_map[branch['fbus']]
        j = bus_idx_map[branch['tbus']]
        
        r, x, b = branch['r'], branch['x'], branch['b']
        if abs(r + 1j*x) > 1e-10:
            y = 1.0 / (r + 1j * x)
        else:
            continue
        y_shunt = 1j * b / 2.0
        
        I_ij = y * (E[i] - E[j]) + y_shunt * E[i]
        I_ji = y * (E[j] - E[i]) + y_shunt * E[j]
        
        S_ij = E[i] * np.conj(I_ij) * baseMVA
        S_ji = E[j] * np.conj(I_ji) * baseMVA
        S_loss = S_ij + S_ji
        
        branch_results.append({
            'From_Bus': branch['fbus'],
            'To_Bus': branch['tbus'],
            'P_from_MW': S_ij.real,
            'Q_from_MVAr': S_ij.imag,
            'P_to_MW': S_ji.real,
            'Q_to_MVAr': S_ji.imag,
            'P_loss_MW': S_loss.real,
            'Q_loss_MVAr': S_loss.imag,
            'I_from_pu': abs(I_ij),
            'I_to_pu': abs(I_ji)
        })
    
    df_bus = pd.DataFrame(bus_results)
    df_branch = pd.DataFrame(branch_results)
    
    df_bus.to_csv('case240_converged_bus_results.csv', index=False)
    df_branch.to_csv('case240_converged_branch_results.csv', index=False)
    
    print(f"\nVoltage Statistics:")
    print(f"  Max: {V_mag.max():.4f} pu")
    print(f"  Min: {V_mag.min():.4f} pu")
    print(f"  Mean: {V_mag.mean():.4f} pu")
    
    violations = np.sum((V_mag < 0.9) | (V_mag > 1.1))
    print(f"  Violations: {violations} buses")
    
    total_gen = sum([S_mva.real for S_mva in [S_pu[i]*baseMVA for i in range(n_buses)] if S_mva.real > 0])
    total_load_calc = sum([bus['Pd'] for bus in buses])
    losses = total_gen - total_load_calc
    
    print(f"\nPower Balance:")
    print(f"  Generation: {total_gen:,.2f} MW")
    print(f"  Load: {total_load_calc:,.2f} MW")
    print(f"  Losses: {losses:,.2f} MW ({losses/total_gen*100:.2f}%)")
    
    # Calculate actual losses from branches
    total_loss_actual = df_branch['P_loss_MW'].sum()
    
    print(f"\nDetailed Power Balance:")
    print(f"  Generation: {total_gen:,.2f} MW")
    print(f"  Load: {total_load_calc:,.2f} MW")
    print(f"  Losses (calculated): {total_loss_actual:,.2f} MW ({total_loss_actual/total_gen*100:.2f}%)")
    
    print(f"\nResults saved to:")
    print(f"  - case240_converged_bus_results.csv")
    print(f"  - case240_converged_branch_results.csv")
    print("="*70)
    
    if converged and max_mismatch < 0.01 and V_mag.max() < 1.15 and V_mag.min() > 0.85:
        print("✓ SUCCESS: Solution converged with reasonable values")
    elif converged:
        print("⚠ PARTIAL: Converged but solution may be stressed")
    else:
        print("✗ FAILED: Did not converge")

except Exception as e:
    print(f"\n✗ ERROR: {str(e)}")
    import traceback
    traceback.print_exc()
