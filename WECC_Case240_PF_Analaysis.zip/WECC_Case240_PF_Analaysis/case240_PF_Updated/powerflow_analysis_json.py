"""
Power Flow Analysis for Case240 using JSON data
Implements Newton-Raphson method in polar coordinates
"""

import json
import numpy as np
import pandas as pd
from NR_polar import NR_polar

def load_case_json(filepath):
    """Load power system case data from JSON file"""
    with open(filepath, 'r') as f:
        return json.load(f)

def build_ybus(case_data):
    """Build the nodal admittance matrix (Y-bus)"""
    buses = case_data['buses']
    branches = case_data['branches']
    baseMVA = case_data['baseMVA']
    
    n_buses = len(buses)
    
    # Create bus index mapping
    bus_ids = [bus['bus_i'] for bus in buses]
    bus_idx_map = {bus_id: idx for idx, bus_id in enumerate(bus_ids)}
    
    # Initialize Y-bus
    Y = np.zeros((n_buses, n_buses), dtype=complex)
    
    # Add branch admittances
    for branch in branches:
        if branch['status'] == 0:
            continue
            
        from_bus = bus_idx_map[branch['fbus']]
        to_bus = bus_idx_map[branch['tbus']]
        
        r = branch['r']
        x = branch['x']
        b = branch['b']
        ratio = branch['ratio'] if branch['ratio'] != 0 else 1.0
        angle = np.deg2rad(branch['angle'])
        
        # Series admittance
        z = r + 1j * x
        if abs(z) > 1e-10:
            y_series = 1.0 / z
        else:
            y_series = 0.0
        
        # Shunt admittance
        y_shunt = 1j * b / 2.0
        
        # Transformer tap ratio
        tap = ratio * np.exp(1j * angle)
        tap_mag_sq = abs(tap) ** 2
        
        # Add to Y-bus matrix
        if ratio == 1.0 and angle == 0.0:
            # Regular line
            Y[from_bus, from_bus] += y_series + y_shunt
            Y[to_bus, to_bus] += y_series + y_shunt
            Y[from_bus, to_bus] -= y_series
            Y[to_bus, from_bus] -= y_series
        else:
            # Transformer
            Y[from_bus, from_bus] += y_series / tap_mag_sq + y_shunt
            Y[to_bus, to_bus] += y_series + y_shunt
            Y[from_bus, to_bus] -= y_series / np.conj(tap)
            Y[to_bus, from_bus] -= y_series / tap
    
    # Add shunt admittances from buses
    for idx, bus in enumerate(buses):
        Y[idx, idx] += (bus['Gs'] + 1j * bus['Bs']) / baseMVA
    
    return Y, bus_idx_map, bus_ids

def run_powerflow(case_filepath, output_filepath=None):
    """
    Run power flow analysis on the case
    
    Args:
        case_filepath: Path to JSON case file
        output_filepath: Path to save results (optional)
    
    Returns:
        Dictionary with results
    """
    print("="*70)
    print("POWER FLOW ANALYSIS - Case 240")
    print("="*70)
    
    # Load case data
    print("\n1. Loading case data...")
    case_data = load_case_json(case_filepath)
    baseMVA = case_data['baseMVA']
    buses = case_data['buses']
    branches = case_data['branches']
    generators = case_data['generators']
    
    print(f"   - Base MVA: {baseMVA}")
    print(f"   - Number of buses: {len(buses)}")
    print(f"   - Number of branches: {len(branches)}")
    print(f"   - Number of generators: {len(generators)}")
    
    # Build Y-bus
    print("\n2. Building Y-bus matrix...")
    Y, bus_idx_map, bus_ids = build_ybus(case_data)
    n_buses = len(buses)
    print(f"   - Y-bus size: {n_buses}x{n_buses}")
    
    # Classify buses and prepare data
    print("\n3. Classifying buses...")
    idx_slack = []
    idx_pv = []
    idx_pq = []
    
    S_star = np.zeros(n_buses, dtype=complex)
    E_star = np.ones(n_buses)
    E_0 = np.ones(n_buses, dtype=complex)
    
    # Create generator map
    gen_map = {}
    for gen in generators:
        bus_idx = bus_idx_map[gen['bus']]
        if bus_idx not in gen_map:
            gen_map[bus_idx] = []
        gen_map[bus_idx].append(gen)
    
    for idx, bus in enumerate(buses):
        bus_type = bus['type']
        
        # Load (negative because it's consumption)
        Pd = bus['Pd'] / baseMVA
        Qd = bus['Qd'] / baseMVA
        
        # Generation
        Pg = 0.0
        Qg = 0.0
        if idx in gen_map:
            for gen in gen_map[idx]:
                if gen['status'] == 1:
                    Pg += gen['Pg'] / baseMVA
                    Qg += gen['Qg'] / baseMVA
        
        # Net injection (generation - load)
        S_star[idx] = (Pg - Pd) + 1j * (Qg - Qd)
        
        # Classify bus
        if bus_type == 3:  # Slack bus
            idx_slack.append(idx)
            E_star[idx] = bus['Vm']
            E_0[idx] = bus['Vm'] * np.exp(1j * np.deg2rad(bus['Va']))
        elif bus_type == 2:  # PV bus
            idx_pv.append(idx)
            E_star[idx] = bus['Vm']
            E_0[idx] = bus['Vm'] * np.exp(1j * np.deg2rad(bus['Va']))
        else:  # PQ bus
            idx_pq.append(idx)
            E_0[idx] = bus['Vm'] * np.exp(1j * np.deg2rad(bus['Va']))
    
    # If no slack bus found, use first generator bus as slack
    if len(idx_slack) == 0:
        print("   WARNING: No slack bus (type 3) found!")
        if len(idx_pv) > 0:
            idx_slack = [idx_pv[0]]
            idx_pv = idx_pv[1:]
            print(f"   Using bus {bus_ids[idx_slack[0]]} as slack bus")
        else:
            print("   ERROR: No generator buses found!")
            return None
    
    idx_slack = np.array(idx_slack)
    idx_pv = np.array(idx_pv)
    idx_pq = np.array(idx_pq)
    
    print(f"   - Slack buses: {len(idx_slack)} (Bus IDs: {[bus_ids[i] for i in idx_slack]})")
    print(f"   - PV buses: {len(idx_pv)}")
    print(f"   - PQ buses: {len(idx_pq)}")
    
    # Run Newton-Raphson
    print("\n4. Running Newton-Raphson power flow...")
    tol = 1e-3  # Increased tolerance from 1e-6 to 1e-3
    n_max = 100
    
    E, S, J, n_iter = NR_polar(Y, S_star, E_star, E_0, 
                                idx_slack[0], idx_pq, idx_pv, 
                                tol, n_max)
    
    print(f"   - Converged in {n_iter} iterations")
    print(f"   - Final tolerance: {tol}")
    
    # Calculate branch flows
    print("\n5. Calculating branch flows...")
    branch_results = []
    
    for branch in branches:
        if branch['status'] == 0:
            continue
            
        from_idx = bus_idx_map[branch['fbus']]
        to_idx = bus_idx_map[branch['tbus']]
        
        E_from = E[from_idx]
        E_to = E[to_idx]
        
        r = branch['r']
        x = branch['x']
        b = branch['b']
        ratio = branch['ratio'] if branch['ratio'] != 0 else 1.0
        angle = np.deg2rad(branch['angle'])
        
        z = r + 1j * x
        if abs(z) > 1e-10:
            y_series = 1.0 / z
        else:
            y_series = 0.0
        y_shunt = 1j * b / 2.0
        
        tap = ratio * np.exp(1j * angle)
        
        # Current flows
        if ratio == 1.0 and angle == 0.0:
            I_from = y_series * (E_from - E_to) + y_shunt * E_from
            I_to = y_series * (E_to - E_from) + y_shunt * E_to
        else:
            I_from = y_series * (E_from / tap - E_to / np.conj(tap)) + y_shunt * E_from / tap
            I_to = y_series * (E_to - E_from / tap) + y_shunt * E_to
        
        # Power flows
        S_from = E_from * np.conj(I_from) * baseMVA
        S_to = E_to * np.conj(I_to) * baseMVA
        S_loss = S_from + S_to
        
        branch_results.append({
            'From_Bus': branch['fbus'],
            'To_Bus': branch['tbus'],
            'P_from_MW': S_from.real,
            'Q_from_MVAr': S_from.imag,
            'P_to_MW': S_to.real,
            'Q_to_MVAr': S_to.imag,
            'P_loss_MW': S_loss.real,
            'Q_loss_MVAr': S_loss.imag,
            'I_from_pu': abs(I_from),
            'I_to_pu': abs(I_to)
        })
    
    # Prepare bus results
    print("\n6. Preparing results...")
    bus_results = []
    
    for idx, bus in enumerate(buses):
        V_mag = abs(E[idx])
        V_ang = np.angle(E[idx], deg=True)
        
        S_inj = S[idx] * baseMVA
        
        # Get generation
        Pg = 0.0
        Qg = 0.0
        if idx in gen_map:
            for gen in gen_map[idx]:
                if gen['status'] == 1:
                    Pg += gen['Pg']
                    Qg = S_inj.imag + bus['Qd']  # Calculate from injection
        
        bus_results.append({
            'Bus': bus['bus_i'],
            'Type': bus['type'],
            'V_mag_pu': V_mag,
            'V_ang_deg': V_ang,
            'P_inj_MW': S_inj.real,
            'Q_inj_MVAr': S_inj.imag,
            'Pg_MW': Pg,
            'Qg_MVAr': Qg,
            'Pd_MW': bus['Pd'],
            'Qd_MVAr': bus['Qd']
        })
    
    # Create DataFrames
    df_bus = pd.DataFrame(bus_results)
    df_branch = pd.DataFrame(branch_results)
    
    # Save results
    if output_filepath:
        bus_output = output_filepath.replace('.csv', '_bus_results.csv')
        branch_output = output_filepath.replace('.csv', '_branch_results.csv')
        
        df_bus.to_csv(bus_output, index=False)
        df_branch.to_csv(branch_output, index=False)
        
        print(f"\n   Results saved to:")
        print(f"   - {bus_output}")
        print(f"   - {branch_output}")
    
    # Calculate summary statistics
    print("\n" + "="*70)
    print("POWER FLOW RESULTS SUMMARY")
    print("="*70)
    
    total_gen_P = df_bus['Pg_MW'].sum()
    total_gen_Q = df_bus['Qg_MVAr'].sum()
    total_load_P = df_bus['Pd_MW'].sum()
    total_load_Q = df_bus['Qd_MVAr'].sum()
    total_loss_P = df_branch['P_loss_MW'].sum()
    total_loss_Q = df_branch['Q_loss_MVAr'].sum()
    
    print(f"\nGeneration:")
    print(f"  Total Active Power:   {total_gen_P:,.2f} MW")
    print(f"  Total Reactive Power: {total_gen_Q:,.2f} MVAr")
    
    print(f"\nLoad:")
    print(f"  Total Active Power:   {total_load_P:,.2f} MW")
    print(f"  Total Reactive Power: {total_load_Q:,.2f} MVAr")
    
    print(f"\nLosses:")
    print(f"  Total Active Power:   {total_loss_P:,.2f} MW")
    print(f"  Total Reactive Power: {total_loss_Q:,.2f} MVAr")
    print(f"  Loss Percentage:      {(total_loss_P/total_gen_P)*100:.2f}%")
    
    print(f"\nVoltage Profile:")
    print(f"  Maximum voltage:      {df_bus['V_mag_pu'].max():.4f} pu (Bus {df_bus.loc[df_bus['V_mag_pu'].idxmax(), 'Bus']:.0f})")
    print(f"  Minimum voltage:      {df_bus['V_mag_pu'].min():.4f} pu (Bus {df_bus.loc[df_bus['V_mag_pu'].idxmin(), 'Bus']:.0f})")
    print(f"  Average voltage:      {df_bus['V_mag_pu'].mean():.4f} pu")
    
    # Find most loaded branches
    df_branch['Loading_%'] = (df_branch['I_from_pu'] * 100).abs()
    top_loaded = df_branch.nlargest(5, 'Loading_%')[['From_Bus', 'To_Bus', 'P_from_MW', 'Loading_%']]
    
    print(f"\nTop 5 Most Loaded Branches:")
    for _, row in top_loaded.iterrows():
        print(f"  {row['From_Bus']:.0f} -> {row['To_Bus']:.0f}: {row['P_from_MW']:,.2f} MW ({row['Loading_%']:.2f}%)")
    
    print("\n" + "="*70)
    
    return {
        'bus_results': df_bus,
        'branch_results': df_branch,
        'voltages': E,
        'powers': S,
        'Y_bus': Y,
        'n_iterations': n_iter
    }

if __name__ == "__main__":
    # Run power flow analysis
    results = run_powerflow(
        case_filepath='case240.json',
        output_filepath='case240_pf_results.csv'
    )
    
    if results:
        print("\nPower flow analysis completed successfully!")
    else:
        print("\nPower flow analysis failed!")
