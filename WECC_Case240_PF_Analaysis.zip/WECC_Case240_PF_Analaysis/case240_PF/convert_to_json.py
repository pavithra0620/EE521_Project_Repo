"""
Script to convert MATLAB power flow case data to JSON format
"""
import json
import re
import csv

def parse_matlab_case(filepath):
    """Parse MATLAB case file and extract bus, branch, and generator data"""
    
    with open(filepath, 'r') as f:
        content = f.read()
    
    case_data = {
        "version": "2",
        "baseMVA": 100.0,
        "buses": [],
        "branches": [],
        "generators": []
    }
    
    # Extract baseMVA
    base_match = re.search(r'mpc\.baseMVA\s*=\s*([\d.]+)', content)
    if base_match:
        case_data["baseMVA"] = float(base_match.group(1))
    
    # Extract bus data
    bus_match = re.search(r'mpc\.bus\s*=\s*\[(.*?)\];', content, re.DOTALL)
    if bus_match:
        bus_lines = bus_match.group(1).strip().split('\n')
        for line in bus_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                # Remove comments and semicolon
                line = re.sub(r'%.*', '', line).strip().rstrip(';')
                values = line.split()
                if len(values) >= 13:
                    bus = {
                        "bus_i": int(values[0]),
                        "type": int(values[1]),
                        "Pd": float(values[2]),
                        "Qd": float(values[3]),
                        "Gs": float(values[4]),
                        "Bs": float(values[5]),
                        "area": int(values[6]),
                        "Vm": float(values[7]),
                        "Va": float(values[8]),
                        "baseKV": float(values[9]),
                        "zone": int(values[10]),
                        "Vmax": float(values[11]),
                        "Vmin": float(values[12])
                    }
                    case_data["buses"].append(bus)
    
    # Extract generator data
    gen_match = re.search(r'mpc\.gen\s*=\s*\[(.*?)\];', content, re.DOTALL)
    if gen_match:
        gen_lines = gen_match.group(1).strip().split('\n')
        for line in gen_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                line = re.sub(r'%.*', '', line).strip().rstrip(';')
                values = line.split()
                if len(values) >= 10:
                    # Handle both 10-column and 21-column formats
                    gen = {
                        "bus": int(values[0]),
                        "Pg": float(values[1]),
                        "Qg": float(values[2]),
                        "Qmax": float(values[3]),
                        "Qmin": float(values[4]),
                        "Vg": float(values[5]),
                        "mBase": float(values[6]),
                        "status": int(values[7]),
                        "Pmax": float(values[8]),
                        "Pmin": float(values[9])
                    }
                    if len(values) >= 21:
                        gen.update({
                            "Pc1": float(values[10]),
                            "Pc2": float(values[11]),
                            "Qc1min": float(values[12]),
                            "Qc1max": float(values[13]),
                            "Qc2min": float(values[14]),
                            "Qc2max": float(values[15]),
                            "ramp_agc": float(values[16]),
                            "ramp_10": float(values[17]),
                            "ramp_30": float(values[18]),
                            "ramp_q": float(values[19]),
                            "apf": float(values[20])
                        })
                    case_data["generators"].append(gen)
    
    # Extract branch data
    branch_match = re.search(r'mpc\.branch\s*=\s*\[(.*?)\];', content, re.DOTALL)
    if branch_match:
        branch_lines = branch_match.group(1).strip().split('\n')
        for line in branch_lines:
            line = line.strip()
            if line and not line.startswith('%'):
                line = re.sub(r'%.*', '', line).strip().rstrip(';')
                values = line.split()
                if len(values) >= 13:
                    branch = {
                        "fbus": int(values[0]),
                        "tbus": int(values[1]),
                        "r": float(values[2]),
                        "x": float(values[3]),
                        "b": float(values[4]),
                        "rateA": float(values[5]),
                        "rateB": float(values[6]),
                        "rateC": float(values[7]),
                        "ratio": float(values[8]),
                        "angle": float(values[9]),
                        "status": int(values[10]),
                        "angmin": float(values[11]),
                        "angmax": float(values[12])
                    }
                    case_data["branches"].append(branch)
    
    return case_data

def csv_to_json(csv_filepath, output_filepath):
    """Convert CSV results to JSON format"""
    data = []
    with open(csv_filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Convert numeric values
            converted_row = {}
            for key, value in row.items():
                try:
                    # Try to convert to float
                    converted_row[key] = float(value)
                except ValueError:
                    # Keep as string if not numeric
                    converted_row[key] = value
            data.append(converted_row)
    
    with open(output_filepath, 'w') as f:
        json.dump(data, f, indent=2)
    
    return data

def main():
    # Convert MATLAB case file to JSON
    print("Converting MATLAB case file to JSON...")
    case_data = parse_matlab_case('pglib_opf_case240_pserc.m')
    
    with open('case240.json', 'w') as f:
        json.dump(case_data, f, indent=2)
    
    print(f"Created case240.json with:")
    print(f"  - {len(case_data['buses'])} buses")
    print(f"  - {len(case_data['branches'])} branches")
    print(f"  - {len(case_data['generators'])} generators")
    
    # Convert bus results CSV to JSON
    print("\nConverting bus results CSV to JSON...")
    bus_results = csv_to_json('case240_bus_results.csv', 'case240_bus_results.json')
    print(f"Created case240_bus_results.json with {len(bus_results)} entries")
    
    # Convert branch results CSV to JSON
    print("\nConverting branch results CSV to JSON...")
    branch_results = csv_to_json('case240_branch_results.csv', 'case240_branch_results.json')
    print(f"Created case240_branch_results.json with {len(branch_results)} entries")
    
    print("\nJSON conversion complete!")

if __name__ == "__main__":
    main()
