================================================================================
POWER FLOW ANALYSIS - CASE240 SHARING INSTRUCTIONS
================================================================================

This document lists all files necessary to share for the Case 240 power flow 
analysis project.

================================================================================
ESSENTIAL FILES TO SHARE
================================================================================

1. INPUT DATA FILES:
   ------------------
   - case240.json                     (Complete system model in JSON format)
   - pglib_opf_case240_pserc.m        (Original MATLAB case file)

2. RESULTS FILES:
   --------------
   - case240_bus_results.csv          (Bus results: voltages, power injections)
   - case240_branch_results.csv       (Branch results: power flows, losses)
   - case240_bus_results.json         (Bus results in JSON format)
   - case240_branch_results.json      (Branch results in JSON format)

3. ANALYSIS SCRIPTS:
   -----------------
   - convert_to_json.py               (Convert MATLAB case to JSON)
   - analyze_json_results.py          (Analyze and summarize results)
   - powerflow_analysis_json.py       (Run power flow analysis from JSON)
   - NR_polar.py                      (Newton-Raphson solver in polar coords)

4. DOCUMENTATION:
   --------------
   - SHARE_FILES_README.txt           (This file - sharing instructions)
   - README.md                        (General project README)
   - PF_Analysis_Report_case240.md    (Analysis report)

================================================================================
OPTIONAL FILES (if recipient needs MATLAB capability)
================================================================================

   - main.m                           (MATLAB main script)
   - NR_polar.m                       (MATLAB Newton-Raphson solver)
   - matlab_scripts/                  (Entire folder with MATLAB scripts)

================================================================================
FILES NOT NEEDED FOR SHARING
================================================================================

   - case240.txt                      (Duplicate of .m file)
   - case240_powerflow_results.mat    (MATLAB binary - platform dependent)
   - case240_pf_results_*.csv         (Unconverged results - not valid)
   - __pycache__/                     (Python cache - auto-generated)
   - PF_Analysis_case240              (Binary/cache file)

================================================================================
PYTHON REQUIREMENTS
================================================================================

To run the Python scripts, the recipient needs:

Python 3.7 or higher with the following packages:
   - numpy
   - pandas
   - json (built-in)

Installation command:
   pip install numpy pandas

================================================================================
HOW TO USE THE SHARED FILES
================================================================================

FOR QUICK ANALYSIS (No computation needed):
------------------------------------------
1. Open the CSV or JSON results files in any spreadsheet or data tool
2. Run: python analyze_json_results.py
   This provides a complete summary without recomputing power flow

FOR VIEWING SYSTEM DATA:
-----------------------
1. Open case240.json in any text editor or JSON viewer
2. The file contains:
   - 240 buses with voltage limits, loads
   - 448 branches with impedances, ratings
   - 143 generators with capacity and dispatch
   - Base MVA: 100.0

FOR RERUNNING POWER FLOW ANALYSIS:
---------------------------------
1. Ensure you have Python with numpy and pandas installed
2. Place all Python scripts in the same folder
3. Run: python powerflow_analysis_json.py
   Note: This may not converge properly due to system conditions

FOR CONVERTING MATLAB TO JSON:
-----------------------------
1. Place pglib_opf_case240_pserc.m and convert_to_json.py in same folder
2. Run: python convert_to_json.py
3. This creates case240.json with complete system data

FOR MATLAB USERS:
----------------
1. Load the case file: mpc = pglib_opf_case240_pserc;
2. Run power flow using MATPOWER or similar toolbox
3. Or use the provided main.m script

================================================================================
SYSTEM SPECIFICATIONS
================================================================================

Case: pglib_opf_case240_pserc (IEEE PES Power Grid Library)
Source: PSERC (Power Systems Engineering Research Center)
Network: Reduced model of WECC (Western Electricity Coordinating Council)

Statistics:
   - Total Buses:           240
   - PQ Buses:             187
   - PV Buses:              52
   - Slack Buses:            1
   - Branches:             448
   - Generators:           143
   - Total Load:       144,180 MW / 15,676 MVAr
   - Gen Capacity:     205,980 MW
   - Base MVA:         100.0

Voltage Levels:
   - 500 kV, 345 kV, 287 kV, 230 kV, 20 kV

================================================================================
RESULTS INTERPRETATION
================================================================================

CSV/JSON Results contain:

BUS RESULTS:
   - Bus: Bus number/ID
   - Type: 1=PQ, 2=PV, 3=Slack
   - V_mag_pu: Voltage magnitude in per unit
   - V_ang_deg: Voltage angle in degrees
   - P_inj_MW: Active power injection (generation - load)
   - Q_inj_MVAr: Reactive power injection
   - Pg_MW: Generated active power
   - Qg_MVAr: Generated reactive power
   - Pd_MW: Active power demand
   - Qd_MVAr: Reactive power demand

BRANCH RESULTS:
   - From_Bus, To_Bus: Branch endpoints
   - P_from_MW: Active power flow from 'from' bus
   - Q_from_MVAr: Reactive power flow from 'from' bus
   - P_to_MW: Active power flow to 'to' bus
   - Q_to_MVAr: Reactive power flow to 'to' bus
   - P_loss_MW: Active power losses
   - Q_loss_MVAr: Reactive power losses
   - I_from_pu: Current magnitude from 'from' bus
   - I_to_pu: Current magnitude to 'to' bus

================================================================================
IMPORTANT NOTES
================================================================================

1. The existing CSV/JSON results (case240_bus_results, case240_branch_results)
   are from a properly converged MATLAB solution and are VALID for analysis.

2. The Python Newton-Raphson implementation (powerflow_analysis_json.py) does
   NOT converge properly for this case. It reaches max iterations (100) without
   achieving convergence tolerance.

3. For reliable power flow computation, use MATLAB/MATPOWER with the provided
   .m file, or use the existing pre-computed results.

4. The JSON format makes the data easily accessible for visualization tools,
   web applications, and other programming languages.

================================================================================
CONTACT INFORMATION
================================================================================

If you have questions about this analysis or need assistance:
- Refer to the original IEEE PES Power Grid Library documentation
- Visit: https://github.com/power-grid-lib/pglib-opf
- Check MATPOWER documentation for power flow analysis details

================================================================================
FILE CHECKLIST FOR SHARING
================================================================================

[ ] case240.json
[ ] pglib_opf_case240_pserc.m
[ ] case240_bus_results.csv
[ ] case240_branch_results.csv
[ ] case240_bus_results.json
[ ] case240_branch_results.json
[ ] convert_to_json.py
[ ] analyze_json_results.py
[ ] powerflow_analysis_json.py
[ ] NR_polar.py
[ ] SHARE_FILES_README.txt
[ ] README.md (if exists)
[ ] PF_Analysis_Report_case240.md (if exists)

OPTIONAL:
[ ] main.m
[ ] NR_polar.m
[ ] matlab_scripts/ folder

================================================================================
END OF SHARING INSTRUCTIONS
================================================================================
Created: November 23, 2025
