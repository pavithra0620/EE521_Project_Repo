"""
Newton-Raphson Power Flow Solver in Polar Coordinates

INPUT:
- Y: Nodal admittance matrix (complex numpy array)
- S_star: Given complex powers (active/reactive powers) (complex numpy array)
- E_star: Given voltage magnitudes (numpy array)
- E_0: Initial voltages (phasors) (complex numpy array)
- idx_slack: Index of the slack bus (int)
- idx_pq: Indices of the PQ buses (numpy array)
- idx_pv: Indices of the PV buses (numpy array)
- tol: Tolerance for convergence criterion (float)
- n_max: Maximum number of iterations (int)

OUTPUT:
- E: Solution voltages (phasors) (complex numpy array)
- S: Complex power injections (complex numpy array)
- J: Jacobian at the solution (numpy array)
- n_iter: Number of iterations (int)
"""

import numpy as np


def NR_polar(Y, S_star, E_star, E_0, idx_slack, idx_pq, idx_pv, tol, n_max):
    Y_abs = np.abs(Y)
    Y_arg = np.angle(Y)
    n_nodes = len(E_0)
    
    # Initialization
    E_abs = np.abs(E_0)
    E_abs[idx_pv] = E_star[idx_pv]  # Set given values for PV nodes
    E_arg = np.angle(E_0)
    J = None
    
    for k in range(n_max):
        n_iter = k + 1
        
        # Compute nodal voltages/currents/power
        E = E_abs * np.exp(1j * E_arg)
        I = Y @ E
        S = E * np.conj(I)
        
        ## Mismatch calculation
        
        # Compute the mismatches for the entire network
        dS = S_star - S
        dP = np.real(dS)
        dQ = np.imag(dS)
        
        # Keep only the relevant mismatches
        dP = np.delete(dP, idx_slack)
        dQ = np.delete(dQ, np.sort(np.concatenate([idx_pv, [idx_slack]])))
        
        dF = np.concatenate([dP, dQ])  # Mismatch of the power flow equations
        
        ## Convergence check
        
        if np.max(np.abs(dF)) < tol:
            # print('NR algorithm has converged to a solution!')
            break
        elif k == n_max - 1:
            print('NR algorithm reached the maximum number of iterations!')
        
        ## Jacobian construction
        
        # For the sake of simplicity, the blocks of J are constructed
        # for the whole network (i.e., with size n_nodes x n_nodes).
        # The unnecessary rows/columns are removed subsequently
        
        # Extract magnitude/angle
        E_abs = np.abs(E)
        E_arg = np.angle(E)
        
        # Initialization
        J_PE = np.zeros((n_nodes, n_nodes))  # derivative: P versus E_abs
        J_PT = np.zeros((n_nodes, n_nodes))  # derivative: P versus E_arg (theta)
        J_QE = np.zeros((n_nodes, n_nodes))  # derivative: Q versus E_abs
        J_QT = np.zeros((n_nodes, n_nodes))  # derivative: Q versus E_arg (theta)
        
        # Construction
        for i in range(n_nodes):
            # Diagonal elements (terms outside the sum)
            J_PE[i, i] = 2 * Y_abs[i, i] * E_abs[i] * np.cos(Y_arg[i, i])
            J_QE[i, i] = -2 * Y_abs[i, i] * E_abs[i] * np.sin(Y_arg[i, i])
            
            for j in range(n_nodes):
                if i != j:
                    a_ij = E_arg[i] - E_arg[j] - Y_arg[i, j]
                    
                    # Diagonal elements (terms inside the sum)
                    J_PE[i, i] += Y_abs[i, j] * E_abs[j] * np.cos(a_ij)
                    J_QE[i, i] += Y_abs[i, j] * E_abs[j] * np.sin(a_ij)
                    J_PT[i, i] -= Y_abs[i, j] * E_abs[i] * E_abs[j] * np.sin(a_ij)
                    J_QT[i, i] += Y_abs[i, j] * E_abs[i] * E_abs[j] * np.cos(a_ij)
                    
                    # Offdiagonal elements
                    J_PE[i, j] = Y_abs[i, j] * E_abs[i] * np.cos(a_ij)
                    J_QE[i, j] = Y_abs[i, j] * E_abs[i] * np.sin(a_ij)
                    J_PT[i, j] = Y_abs[i, j] * E_abs[i] * E_abs[j] * np.sin(a_ij)
                    J_QT[i, j] = -Y_abs[i, j] * E_abs[i] * E_abs[j] * np.cos(a_ij)
        
        # Remove extra rows (i.e., unnecessary equations)
        # slack bus: P & Q, PV buses: Q
        
        J_PE = np.delete(J_PE, idx_slack, axis=0)
        J_PT = np.delete(J_PT, idx_slack, axis=0)
        
        idx_remove = np.sort(np.concatenate([idx_pv, [idx_slack]]))
        J_QE = np.delete(J_QE, idx_remove, axis=0)
        J_QT = np.delete(J_QT, idx_remove, axis=0)
        
        # Remove extra columns (i.e., variables)
        # slack bus: E_abs & E_arg, PV nodes: E_abs
        
        idx_remove_col = np.sort(np.concatenate([idx_pv, [idx_slack]]))
        J_PE = np.delete(J_PE, idx_remove_col, axis=1)
        J_QE = np.delete(J_QE, idx_remove_col, axis=1)
        
        J_PT = np.delete(J_PT, idx_slack, axis=1)
        J_QT = np.delete(J_QT, idx_slack, axis=1)
        
        # Combination
        J = np.block([[J_PE, J_PT], [J_QE, J_QT]])
        
        ## Solution update
        
        # Solve
        dx = np.linalg.solve(J, dF)
        
        # Reconstruct the solution
        dE_abs = np.zeros(len(E_abs))
        dE_abs[idx_pq] = dx[:len(idx_pq)]
        
        dE_arg = np.zeros(len(E_arg))
        idx_angle = np.sort(np.concatenate([idx_pq, idx_pv]))
        dE_arg[idx_angle] = dx[len(idx_pq):]
        
        # Update
        E_abs = E_abs + dE_abs
        E_arg = E_arg + dE_arg
        
        E_abs[idx_pv] = E_star[idx_pv]
    
    E = E_abs * np.exp(1j * E_arg)
    
    # Recalculate final S
    I = Y @ E
    S = E * np.conj(I)
    
    return E, S, J, n_iter
