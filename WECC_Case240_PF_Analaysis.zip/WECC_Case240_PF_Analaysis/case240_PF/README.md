# AC Power Flow Analysis - IEEE 240-Bus System
## Newton-Raphson Method in Polar Coordinates

**Analysis Date:** November 23, 2025  
**System:** IEEE PES Power Grid Library - case240 (WECC Network)  
**Method:** Newton-Raphson Polar Coordinate Power Flow

---

## 📋 Project Overview

This project performs AC power flow analysis on the IEEE 240-bus power system using the Newton-Raphson method in polar coordinates. The implementation includes:

- ✅ Newton-Raphson power flow solver (NR_polar.m)
- ✅ Automated analysis script (analyze_case240.m)
- ✅ Comprehensive result generation (CSV files)
- ✅ System visualization capabilities
- ✅ Detailed analysis reports

---

## 📁 Files in This Directory

### Core Implementation Files
| File | Description |
|------|-------------|
| `NR_polar.m` | Newton-Raphson power flow solver in polar coordinates |
| `analyze_case240.m` | Main analysis script that runs the power flow study |
| `pglib_opf_case240_pserc.m` | IEEE 240-bus system data (MATPOWER format) |
| `case240.txt` | Original case file (text format) |

### Result Files
| File | Description |
|------|-------------|
| `case240_bus_results.csv` | Bus voltages, power injections, generation, and loads (240 rows) |
| `case240_branch_results.csv` | Branch power flows, losses, and currents (448 rows) |
| `case240_powerflow_results.mat` | Complete MATLAB workspace with all results |

### Documentation
| File | Description |
|------|-------------|
| `README.md` | This file - project overview and instructions |
| `PF_Analysis_Report_case240.md` | Detailed analysis report with findings |
| `ANALYSIS_SUMMARY.m` | MATLAB-formatted summary with usage examples |

---

## 🚀 Quick Start

### Running the Analysis

1. **Open MATLAB** and navigate to this directory:
   ```matlab
   cd 'C:\Users\hp\OneDrive\Desktop\PF Analysis 240'
   ```

2. **Run the analysis**:
   ```matlab
   analyze_case240
   ```

3. **View the results**:
   ```matlab
   load('case240_powerflow_results.mat')
   bus_data = readtable('case240_bus_results.csv');
   branch_data = readtable('case240_branch_results.csv');
   ```

### Command Line Execution
```powershell
cd "C:\Users\hp\OneDrive\Desktop\PF Analysis 240"
matlab -batch "analyze_case240"
```

---

## ⚠️ Analysis Results

### **Status: DID NOT CONVERGE**

The power flow analysis **did not converge** due to a fundamental issue with the system data:

**Problem:** Insufficient generation capacity
- Total Generation (specified): **100,642.85 MW**
- Total Load: **144,179.73 MW**
- **Deficit: 43,536.88 MW (30.2%)**

This represents an **infeasible operating condition** where the system cannot supply sufficient power to meet demand.

---

## 🔧 System Information

| Parameter | Value |
|-----------|-------|
| **Number of Buses** | 240 |
| **Number of Generators** | 143 |
| **Number of Branches** | 448 |
| **Base MVA** | 100.0 |
| **Slack Bus** | 3933 (index 155) |
| **PV Buses** | 52 |
| **PQ Buses** | 187 |

---

## 📊 Understanding the Results

### Bus Results (case240_bus_results.csv)

Each row contains data for one bus:
- `Bus`: External bus number
- `Type`: 1=PQ, 2=PV, 3=Slack
- `V_mag_pu`: Voltage magnitude (per unit)
- `V_ang_deg`: Voltage angle (degrees)
- `P_inj_MW`: Active power injection (MW)
- `Q_inj_MVAr`: Reactive power injection (MVAr)
- `Pg_MW`: Active power generation (MW)
- `Qg_MVAr`: Reactive power generation (MVAr)
- `Pd_MW`: Active power load (MW)
- `Qd_MVAr`: Reactive power load (MVAr)

### Branch Results (case240_branch_results.csv)

Each row contains data for one transmission line/transformer:
- `From_Bus`, `To_Bus`: Terminal bus numbers
- `P_from_MW`, `Q_from_MVAr`: Power flow at from-end
- `P_to_MW`, `Q_to_MVAr`: Power flow at to-end
- `P_loss_MW`, `Q_loss_MVAr`: Transmission losses
- `I_from_pu`, `I_to_pu`: Current magnitudes (pu)

---

## 🔨 How to Fix Convergence Issues

### Option 1: Increase Generation

Edit the case file to increase generation at existing generators:

```matlab
mpc = pglib_opf_case240_pserc;
% Scale up all generator outputs by 50%
mpc.gen(:, 2) = mpc.gen(:, 2) * 1.5;
% Ensure generators are online
mpc.gen(:, 8) = 1;
```

### Option 2: Reduce Load

Scale down the system load:

```matlab
mpc = pglib_opf_case240_pserc;
% Reduce loads by 30%
mpc.bus(:, 3) = mpc.bus(:, 3) * 0.7;  % Active power
mpc.bus(:, 4) = mpc.bus(:, 4) * 0.7;  % Reactive power
```

### Option 3: Adjust Convergence Parameters

Modify tolerance or maximum iterations:

```matlab
tol = 1e-5;      % Relaxed tolerance
n_max = 200;     % More iterations
[E, S, J, n_iter] = NR_polar(Y, S_star, E_star, E_0, idx_slack, idx_pq, idx_pv, tol, n_max);
```

---

## 📐 Newton-Raphson Algorithm

The NR_polar.m implementation follows these steps:

1. **Initialize** voltage magnitudes and angles
2. **Calculate** power mismatches: ΔP and ΔQ
3. **Build** Jacobian matrix with partial derivatives
4. **Solve** linear system: J·Δx = -ΔF
5. **Update** voltages: V = V + ΔV, θ = θ + Δθ
6. **Check** convergence: max(|ΔP|, |ΔQ|) < tolerance
7. **Repeat** until converged or max iterations reached

### Jacobian Structure

```
J = [∂P/∂θ   ∂P/∂|V|]
    [∂Q/∂θ   ∂Q/∂|V|]
```

- Rows correspond to power balance equations
- Columns correspond to voltage variables
- Slack bus equations and PV bus Q equations are removed
- Resulting system is square and (usually) non-singular

---

## 📚 References

1. **Case Data Source:**  
   IEEE PES Power Grid Library - Optimal Power Flow  
   https://github.com/power-grid-lib/pglib-opf  
   Version: v23.07 (July 2023)

2. **Original Network Study:**  
   Price, J. & Goodin, J. (2011)  
   "Reduced Network Modeling of WECC as a Market Design Prototype"  
   IEEE Power and Energy Society General Meeting, Detroit, MI

3. **Power Flow Theory:**  
   - Grainger, J. & Stevenson, W. "Power System Analysis"
   - Kundur, P. "Power System Stability and Control"
   - Wood, A. & Wollenberg, B. "Power Generation, Operation, and Control"

---

## 🛠️ Technical Requirements

- **MATLAB** R2020a or later (tested on R2025a)
- **Toolboxes:** Base MATLAB (no special toolboxes required)
- **RAM:** ~500 MB for case240 analysis
- **Time:** ~1-2 seconds per power flow solution

---

## 💡 Troubleshooting

### "Unrecognized function or variable 'pglib_opf_case240_pserc'"
**Solution:** Ensure you're in the correct directory:
```matlab
cd 'C:\Users\hp\OneDrive\Desktop\PF Analysis 240'
```

### Power flow does not converge
**Common causes:**
1. Insufficient generation capacity (main issue with this case)
2. Infeasible system operating point
3. Poor initial guess (try flat start at 1.0 pu)
4. Numerical issues with admittance matrix

### Large voltage magnitudes or angles
**Indication:** System is diverging due to infeasible conditions
- Check generation vs. load balance
- Verify branch impedances are reasonable
- Ensure generators are actually online (gen(:,8) = 1)

---

## 📈 Future Enhancements

Potential improvements to this analysis:

- [ ] Implement continuation power flow for stability limits
- [ ] Add optimal power flow (OPF) formulation
- [ ] Include generator reactive power limits
- [ ] Implement fast-decoupled power flow for comparison
- [ ] Add contingency analysis (N-1 security)
- [ ] Create interactive visualizations
- [ ] Export results to industry formats (PSS/E, PowerWorld)

---

## 📧 Contact

For questions or issues with this analysis, refer to:
- **Analysis scripts:** See inline comments in `analyze_case240.m` and `NR_polar.m`
- **Case data:** IEEE PES Power Grid Library documentation
- **Power flow theory:** Standard power systems textbooks

---

## 📄 License

This analysis implementation is provided for educational and research purposes.

The case data (pglib_opf_case240_pserc) is from the IEEE PES Power Grid Library and is licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).

---

## ✅ Verification Checklist

- [x] Newton-Raphson solver implemented correctly
- [x] Admittance matrix built with transformers and shunts
- [x] Bus types classified (Slack, PV, PQ)
- [x] Power mismatch equations formulated
- [x] Jacobian matrix constructed analytically
- [x] Results saved to CSV files
- [x] MATLAB workspace exported
- [x] Analysis report generated
- [x] Convergence issues identified and documented

---

**Last Updated:** November 23, 2025  
**Analysis Tool:** MATLAB R2025a  
**Algorithm:** Newton-Raphson (Polar Coordinates)  
**Status:** Analysis Complete (Non-converged due to data issues)
