"""
Quick Power Flow Summary from JSON Data
Analyzes the existing results and case data
"""

import json
import pandas as pd
import numpy as np

def analyze_json_results():
    """Analyze power flow results from JSON files"""
    
    print("="*70)
    print("POWER FLOW ANALYSIS SUMMARY - Case 240")
    print("="*70)
    
    # Load case data
    with open('case240.json', 'r') as f:
        case_data = json.load(f)
    
    with open('case240_bus_results.json', 'r') as f:
        bus_results = json.load(f)
    
    with open('case240_branch_results.json', 'r') as f:
        branch_results = json.load(f)
    
    df_bus = pd.DataFrame(bus_results)
    df_branch = pd.DataFrame(branch_results)
    
    print(f"\n1. SYSTEM DATA:")
    print(f"   - Base MVA: {case_data['baseMVA']}")
    print(f"   - Number of buses: {len(case_data['buses'])}")
    print(f"   - Number of branches: {len(case_data['branches'])}")
    print(f"   - Number of generators: {len(case_data['generators'])}")
    
    # Count bus types
    bus_types = pd.DataFrame(case_data['buses'])['type'].value_counts()
    print(f"\n2. BUS CLASSIFICATION:")
    for bus_type, count in bus_types.items():
        type_name = {1: "PQ", 2: "PV", 3: "Slack"}[bus_type]
        print(f"   - {type_name} buses: {count}")
    
    # Generation summary
    total_pg = sum([gen['Pg'] for gen in case_data['generators'] if gen['status'] == 1])
    total_pmax = sum([gen['Pmax'] for gen in case_data['generators'] if gen['status'] == 1])
    
    print(f"\n3. GENERATION:")
    print(f"   - Total Generation Capacity: {total_pmax:,.2f} MW")
    print(f"   - Current Generation: {total_pg:,.2f} MW")
    print(f"   - Capacity Factor: {(total_pg/total_pmax)*100:.2f}%")
    print(f"   - Active Generators: {sum(1 for g in case_data['generators'] if g['status'] == 1)}")
    
    # Load summary
    total_load_p = sum([bus['Pd'] for bus in case_data['buses']])
    total_load_q = sum([bus['Qd'] for bus in case_data['buses']])
    
    print(f"\n4. LOAD:")
    print(f"   - Total Active Power: {total_load_p:,.2f} MW")
    print(f"   - Total Reactive Power: {total_load_q:,.2f} MVAr")
    print(f"   - Power Factor: {total_load_p/np.sqrt(total_load_p**2 + total_load_q**2):.3f}")
    
    # Power flow results
    print(f"\n5. POWER FLOW RESULTS:")
    print(f"   - Total Active Losses: {df_branch['P_loss_MW'].sum():,.2f} MW")
    print(f"   - Total Reactive Losses: {df_branch['Q_loss_MVAr'].sum():,.2f} MVAr")
    print(f"   - Loss Percentage: {(df_branch['P_loss_MW'].sum()/total_pg)*100:.2f}%")
    
    # Voltage profile
    print(f"\n6. VOLTAGE PROFILE:")
    print(f"   - Maximum: {df_bus['V_mag_pu'].max():.4f} pu (Bus {df_bus.loc[df_bus['V_mag_pu'].idxmax(), 'Bus']:.0f})")
    print(f"   - Minimum: {df_bus['V_mag_pu'].min():.4f} pu (Bus {df_bus.loc[df_bus['V_mag_pu'].idxmin(), 'Bus']:.0f})")
    print(f"   - Average: {df_bus['V_mag_pu'].mean():.4f} pu")
    print(f"   - Std Dev: {df_bus['V_mag_pu'].std():.4f} pu")
    
    # Buses outside limits
    v_violations = df_bus[(df_bus['V_mag_pu'] < 0.9) | (df_bus['V_mag_pu'] > 1.1)]
    if len(v_violations) > 0:
        print(f"\n   WARNING: {len(v_violations)} buses with voltage violations:")
        for _, bus in v_violations.head(10).iterrows():
            print(f"      Bus {bus['Bus']:.0f}: {bus['V_mag_pu']:.4f} pu")
    else:
        print(f"\n   All voltages within limits (0.9 - 1.1 pu)")
    
    # Branch loading
    df_branch['Loading_pct'] = df_branch['I_from_pu'] * 100
    top_loaded = df_branch.nlargest(10, 'Loading_pct')
    
    print(f"\n7. TOP 10 MOST LOADED BRANCHES:")
    for idx, row in top_loaded.iterrows():
        print(f"   {row['From_Bus']:.0f} -> {row['To_Bus']:.0f}: {row['P_from_MW']:,.2f} MW, Current: {row['Loading_pct']:.2f}%")
    
    # Find critical buses (highest power injection)
    critical_buses = df_bus.nlargest(10, 'P_inj_MW')
    
    print(f"\n8. TOP 10 BUSES BY POWER INJECTION:")
    for _, bus in critical_buses.iterrows():
        print(f"   Bus {bus['Bus']:.0f}: P={bus['P_inj_MW']:,.2f} MW, Q={bus['Q_inj_MVAr']:,.2f} MVAr, V={bus['V_mag_pu']:.4f} pu")
    
    # Generator buses
    gen_buses = set([gen['bus'] for gen in case_data['generators'] if gen['status'] == 1])
    df_gen_buses = df_bus[df_bus['Bus'].isin(gen_buses)].copy()
    
    print(f"\n9. GENERATOR BUSES SUMMARY:")
    print(f"   - Number of generator buses: {len(df_gen_buses)}")
    print(f"   - Average voltage: {df_gen_buses['V_mag_pu'].mean():.4f} pu")
    print(f"   - Total generation (from results): {df_gen_buses['Pg_MW'].sum():,.2f} MW")
    print(f"   - Total reactive generation: {df_gen_buses['Qg_MVAr'].sum():,.2f} MVAr")
    
    print("\n" + "="*70)
    print("Analysis complete! JSON data successfully analyzed.")
    print("="*70)
    
    return case_data, df_bus, df_branch

if __name__ == "__main__":
    case_data, df_bus, df_branch = analyze_json_results()
